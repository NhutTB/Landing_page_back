// ====== constants/colors.js ======
export const COLORS = {
  primary: '#2E4DFF',
  primaryDark: '#2540E6',
  primaryLight: '#F1F5FF',
  background: '#FFFFFF',
  surface: '#F8FAFC',
  border: '#E2E8F0',
  textPrimary: '#0F172A',
  textSecondary: '#475569',
  textTertiary: '#94A3B8',
  success: '#10B981',
  warning: '#F59E0B',
  error: '#EF4444',
};

