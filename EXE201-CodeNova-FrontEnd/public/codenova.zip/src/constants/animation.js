// ====== constants/animations.js (Enhanced) ======
export const animationsCSS = `
  /* ✨ Advanced Keyframes */
  @keyframes fadeIn {
    from {
      opacity: 0;
      transform: translateY(-4px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  @keyframes fadeOut {
    from {
      opacity: 1;
      transform: scale(1);
    }
    to {
      opacity: 0;
      transform: scale(0.96);
    }
  }

  @keyframes slideInRight {
    from {
      opacity: 0;
      transform: translateX(30px);
    }
    to {
      opacity: 1;
      transform: translateX(0);
    }
  }

  @keyframes slideOutRight {
    from {
      opacity: 1;
      transform: translateX(0);
    }
    to {
      opacity: 0;
      transform: translateX(30px);
    }
  }

  @keyframes slideInLeft {
    from {
      opacity: 0;
      transform: translateX(-30px);
    }
    to {
      opacity: 1;
      transform: translateX(0);
    }
  }

  @keyframes slideUp {
    from {
      opacity: 0;
      transform: translateY(20px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  @keyframes slideDown {
    from {
      opacity: 0;
      transform: translateY(-20px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  @keyframes scaleIn {
    from {
      opacity: 0;
      transform: scale(0.9);
    }
    to {
      opacity: 1;
      transform: scale(1);
    }
  }

  @keyframes scaleOut {
    from {
      opacity: 1;
      transform: scale(1);
    }
    to {
      opacity: 0;
      transform: scale(0.9);
    }
  }

  @keyframes pulse {
    0%, 100% {
      opacity: 1;
      transform: scale(1);
    }
    50% {
      opacity: 0.9;
      transform: scale(1.03);
    }
  }

  @keyframes bounce {
    0%, 100% {
      transform: translateY(0);
    }
    50% {
      transform: translateY(-8px);
    }
  }

  @keyframes spin {
    to {
      transform: rotate(360deg);
    }
  }

  @keyframes shimmer {
    0% {
      background-position: -1000px 0;
    }
    100% {
      background-position: 1000px 0;
    }
  }

  @keyframes progress {
    0% {
      transform: translateX(-100%);
    }
    100% {
      transform: translateX(100%);
    }
  }

  @keyframes wiggle {
    0%, 100% {
      transform: rotate(0deg);
    }
    25% {
      transform: rotate(-3deg);
    }
    75% {
      transform: rotate(3deg);
    }
  }

  @keyframes shake {
    0%, 100% {
      transform: translateX(0);
    }
    25% {
      transform: translateX(-4px);
    }
    75% {
      transform: translateX(4px);
    }
  }

  @keyframes glow {
    0%, 100% {
      box-shadow: 0 0 5px rgba(46, 77, 255, 0.3);
    }
    50% {
      box-shadow: 0 0 20px rgba(46, 77, 255, 0.6);
    }
  }

  @keyframes gradient-x {
    0%, 100% {
      background-position: 0% 50%;
    }
    50% {
      background-position: 100% 50%;
    }
  }

  @keyframes float {
    0%, 100% {
      transform: translateY(0px);
    }
    50% {
      transform: translateY(-6px);
    }
  }

  /* ✨ Animation Classes */
  .animate-fadeIn {
    animation: fadeIn 0.4s cubic-bezier(0.4, 0, 0.2, 1) forwards;
  }

  .animate-fadeOut {
    animation: fadeOut 0.3s cubic-bezier(0.4, 0, 1, 1) forwards;
  }

  .animate-slideInRight {
    animation: slideInRight 0.45s cubic-bezier(0.16, 1, 0.3, 1) forwards;
  }

  .animate-slideOutRight {
    animation: slideOutRight 0.35s cubic-bezier(0.4, 0, 1, 1) forwards;
  }

  .animate-slideInLeft {
    animation: slideInLeft 0.45s cubic-bezier(0.16, 1, 0.3, 1) forwards;
  }

  .animate-slideUp {
    animation: slideUp 0.45s cubic-bezier(0.16, 1, 0.3, 1) forwards;
  }

  .animate-slideDown {
    animation: slideDown 0.45s cubic-bezier(0.16, 1, 0.3, 1) forwards;
  }

  .animate-scaleIn {
    animation: scaleIn 0.35s cubic-bezier(0.16, 1, 0.3, 1) forwards;
  }

  .animate-scaleOut {
    animation: scaleOut 0.25s cubic-bezier(0.4, 0, 1, 1) forwards;
  }

  .animate-pulse {
    animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
  }

  .animate-bounce {
    animation: bounce 1s ease-in-out infinite;
  }

  .animate-spin {
    animation: spin 1s linear infinite;
  }

  .animate-shimmer {
    animation: shimmer 2s linear infinite;
    background: linear-gradient(
      90deg,
      rgba(255, 255, 255, 0) 0%,
      rgba(255, 255, 255, 0.4) 50%,
      rgba(255, 255, 255, 0) 100%
    );
    background-size: 1000px 100%;
  }

  .animate-wiggle {
    animation: wiggle 0.5s ease-in-out;
  }

  .animate-shake {
    animation: shake 0.4s ease-in-out;
  }

  .animate-glow {
    animation: glow 2s ease-in-out infinite;
  }

  .animate-gradient-x {
    animation: gradient-x 3s ease infinite;
    background-size: 200% 200%;
  }

  .animate-float {
    animation: float 3s ease-in-out infinite;
  }

  /* ✨ Delay Utilities */
  .delay-75 { animation-delay: 75ms; }
  .delay-100 { animation-delay: 100ms; }
  .delay-150 { animation-delay: 150ms; }
  .delay-200 { animation-delay: 200ms; }
  .delay-300 { animation-delay: 300ms; }
  .delay-500 { animation-delay: 500ms; }

  /* ✨ Duration Utilities */
  .duration-75 { animation-duration: 75ms; }
  .duration-100 { animation-duration: 100ms; }
  .duration-150 { animation-duration: 150ms; }
  .duration-200 { animation-duration: 200ms; }
  .duration-300 { animation-duration: 300ms; }
  .duration-500 { animation-duration: 500ms; }
  .duration-700 { animation-duration: 700ms; }
  .duration-1000 { animation-duration: 1000ms; }

  /* ✨ Smooth Transitions */
  * {
    transition-property: color, background-color, border-color, opacity, transform, box-shadow;
    transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
    transition-duration: 200ms;
  }

  /* ✨ Enhanced Button Interactions */
  button, [role="button"] {
    position: relative;
    overflow: hidden;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  }

  button::before, [role="button"]::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    width: 0;
    height: 0;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.3);
    transform: translate(-50%, -50%);
    transition: width 0.6s, height 0.6s;
  }

  button:active::before, [role="button"]:active::before {
    width: 300px;
    height: 300px;
  }

  button:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(46, 77, 255, 0.25);
  }

  button:active {
    transform: scale(0.97);
    box-shadow: 0 2px 6px rgba(46, 77, 255, 0.2);
  }

  button:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none !important;
  }

  /* ✨ Enhanced Card Interactions */
  .card-hover {
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  }

  .card-hover:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);
  }

  /* ✨ Glassmorphism Effect */
  .glass {
    background: rgba(255, 255, 255, 0.7);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    border: 1px solid rgba(255, 255, 255, 0.3);
  }

  .glass-dark {
    background: rgba(0, 0, 0, 0.4);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    border: 1px solid rgba(255, 255, 255, 0.1);
  }

  /* ✨ Loading Skeleton */
  .skeleton {
    background: linear-gradient(
      90deg,
      #f0f0f0 25%,
      #e0e0e0 50%,
      #f0f0f0 75%
    );
    background-size: 200% 100%;
    animation: shimmer 1.5s infinite;
  }

  /* ✨ Scrollbar Styling */
  ::-webkit-scrollbar {
    width: 8px;
    height: 8px;
  }

  ::-webkit-scrollbar-track {
    background: rgba(0, 0, 0, 0.05);
    border-radius: 4px;
  }

  ::-webkit-scrollbar-thumb {
    background: rgba(46, 77, 255, 0.3);
    border-radius: 4px;
    transition: background 0.2s;
  }

  ::-webkit-scrollbar-thumb:hover {
    background: rgba(46, 77, 255, 0.5);
  }

  /* ✨ Focus Visible */
  *:focus-visible {
    outline: 2px solid rgba(46, 77, 255, 0.5);
    outline-offset: 2px;
    border-radius: 4px;
  }

  /* ✨ Selection */
  ::selection {
    background: rgba(46, 77, 255, 0.2);
    color: inherit;
  }

  /* ✨ Reduced Motion Support */
  @media (prefers-reduced-motion: reduce) {
    *,
    *::before,
    *::after {
      animation-duration: 0.01ms !important;
      animation-iteration-count: 1 !important;
      transition-duration: 0.01ms !important;
    }
  }
`;

export const ANIMATION_CONFIG = {
  timing: {
    fast: 150,
    normal: 300,
    slow: 500,
  },
  easing: {
    easeInOut: 'cubic-bezier(0.4, 0, 0.2, 1)',
    easeOut: 'cubic-bezier(0.16, 1, 0.3, 1)',
    easeIn: 'cubic-bezier(0.4, 0, 1, 1)',
    bounce: 'cubic-bezier(0.68, -0.55, 0.265, 1.55)',
  },
};