// ====== components/PageListItem.jsx (Enhanced) ======
import React, { useState, useCallback } from 'react';
import { Edit3, Trash2, Check, Clock, AlertCircle } from 'lucide-react';

export const PageListItem = React.memo(({ image, isSelected, onSelect, onEdit, onDelete }) => {
  const [isDeleting, setIsDeleting] = useState(false);

  const handleDelete = useCallback(async (e) => {
    e.stopPropagation();
    setIsDeleting(true);
    // Delay for animation
    await new Promise(resolve => setTimeout(resolve, 300));
    onDelete(image.id);
  }, [image.id, onDelete]);

  const statusColors = {
    pending: 'text-slate-400 bg-slate-50',
    queued: 'text-blue-500 bg-blue-50',
    translating: 'text-sky-500 bg-sky-50 animate-pulse',
    done: 'text-emerald-500 bg-emerald-50',
    error: 'text-rose-500 bg-rose-50',
  };

  const StatusIcon = {
    pending: Clock,
    queued: Clock,
    translating: Clock,
    done: Check,
    error: AlertCircle,
  }[image.status] || Clock;

  return (
    <div
      onClick={() => onSelect(image.id)}
      className={`relative flex items-center gap-3 p-3 rounded-xl border-2 transition-all duration-300 cursor-pointer group card-hover ${
        isDeleting ? 'animate-scaleOut' : 'animate-slideInLeft'
      } ${
        isSelected 
          ? 'bg-gradient-to-br from-sky-50 to-blue-50 border-sky-400 shadow-lg scale-[1.02]' 
          : 'bg-white border-slate-200 hover:border-sky-300 hover:shadow-md'
      }`}
    >
      {/* Selection Checkbox */}
      <div className="relative">
        <input
          type="checkbox"
          checked={isSelected}
          onChange={() => {}}
          className="w-5 h-5 accent-sky-500 cursor-pointer transition-all duration-200 hover:scale-110"
        />
        {isSelected && (
          <div className="absolute inset-0 rounded bg-sky-500/20 animate-ping" />
        )}
      </div>

      {/* Image Thumbnail */}
      <div className="relative overflow-hidden rounded-lg">
        <img
          src={image.thumb}
          alt={image.name}
          className="w-16 h-20 object-cover border border-slate-200 transition-all duration-300 group-hover:scale-110 group-hover:brightness-105"
        />
        {/* Status Badge Overlay */}
        <div className={`absolute top-1 right-1 p-1 rounded-md ${statusColors[image.status]} shadow-sm`}>
          <StatusIcon size={10} />
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-slate-700 truncate group-hover:text-sky-600 transition-colors">
          {image.name}
        </p>
        
        {/* Status Indicator */}
        <div className="flex items-center gap-2 mt-1">
          <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${statusColors[image.status]}`}>
            {image.status === 'pending' && 'Chờ xử lý'}
            {image.status === 'queued' && 'Hàng đợi'}
            {image.status === 'translating' && 'Đang dịch'}
            {image.status === 'done' && 'Hoàn thành'}
            {image.status === 'error' && 'Lỗi'}
          </span>
          {image.duration && (
            <span className="text-xs text-slate-400">
              {image.duration}s
            </span>
          )}
        </div>

        {/* Dimensions */}
        {(image.width || image.height) && (
          <p className="text-xs text-slate-400 mt-1">
            {image.width} × {image.height}
          </p>
        )}
      </div>

      {/* Action Buttons */}
      <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-all duration-200">
        <button
          onClick={(e) => {
            e.stopPropagation();
            onEdit(image.id);
          }}
          className="p-2 rounded-lg text-slate-500 hover:bg-sky-100 hover:text-sky-600 transition-all duration-200 hover:scale-110 active:scale-95"
          title="Chỉnh sửa"
        >
          <Edit3 size={16} />
        </button>
        <button
          onClick={handleDelete}
          className="p-2 rounded-lg text-slate-500 hover:bg-rose-100 hover:text-rose-600 transition-all duration-200 hover:scale-110 active:scale-95"
          title="Xóa"
        >
          <Trash2 size={16} />
        </button>
      </div>

      {/* Selection Glow Effect */}
      {isSelected && (
        <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-sky-400/10 via-blue-400/10 to-indigo-400/10 animate-pulse pointer-events-none" />
      )}
    </div>
  );
});

PageListItem.displayName = 'PageListItem';