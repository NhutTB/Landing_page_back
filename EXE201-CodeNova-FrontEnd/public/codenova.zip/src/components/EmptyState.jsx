// ====== components/EmptyState.jsx (Redesigned) ======
import React from 'react';

export const EmptyState = React.memo(({ isLoading = false }) => {
  if (isLoading) {
    return (
      <div className="codenova-loading-state">
        <div className="codenova-loading-icon">
          <svg viewBox="0 0 24 24" fill="none">
            <circle
              cx="12"
              cy="12"
              r="10"
              stroke="currentColor"
              strokeWidth="2"
            />
            <path
              d="M12 6v6l4 2"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
            />
          </svg>
        </div>
        <h3 className="codenova-loading-title">Đang quét trang...</h3>
        <p className="codenova-loading-description">
          Đang tìm kiếm và phân tích các ảnh truyện trên trang
        </p>
        <div className="codenova-loading-dots">
          <div className="codenova-loading-dot" />
          <div className="codenova-loading-dot" />
          <div className="codenova-loading-dot" />
        </div>
      </div>
    );
  }

  return (
    <div className="codenova-empty-state">
      <div className="codenova-empty-icon">
        <svg viewBox="0 0 24 24" fill="none">
          <path
            d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9zM4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm3 4a1 1 0 000 2h.01a1 1 0 100-2H7zm3 0a1 1 0 000 2h3a1 1 0 100-2h-3zm-3 4a1 1 0 100 2h.01a1 1 0 100-2H7zm3 0a1 1 0 100 2h3a1 1 0 100-2h-3z"
            fill="currentColor"
          />
        </svg>
      </div>
      <h3 className="codenova-empty-title">Không tìm thấy ảnh truyện</h3>
      <p className="codenova-empty-description">
        Hãy kiểm tra xem trang có chứa ảnh hay không, hoặc thử tải lại trang
      </p>
      <div className="codenova-empty-suggestions">
        <div className="codenova-suggestion-item">
          <div className="codenova-suggestion-dot" />
          <span>Đảm bảo trang đã tải xong</span>
        </div>
        <div className="codenova-suggestion-item">
          <div className="codenova-suggestion-dot" />
          <span>Kiểm tra định dạng ảnh hợp lệ</span>
        </div>
        <div className="codenova-suggestion-item">
          <div className="codenova-suggestion-dot" />
          <span>Thử làm mới lại panel</span>
        </div>
      </div>
    </div>
  );
});

EmptyState.displayName = 'EmptyState';