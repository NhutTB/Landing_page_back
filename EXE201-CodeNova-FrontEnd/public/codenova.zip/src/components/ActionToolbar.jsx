// ====== components/ActionToolbar.jsx (Updated with Abort Button) ======
import React, { useState, useCallback } from 'react';

export const ActionToolbar = React.memo(
  ({ onTranslatePage, onTranslateAll, onTranslateSelected, selectedCount = 0, isLoading = false, onAbort }) => {
    const [sourceLang, setSourceLang] = useState('ch');
    const [targetLang, setTargetLang] = useState('vi');

    const languages = [
      { code: 'ch', label: '🇨🇳 中文 (CN)' },
      { code: 'jp', label: '🇯🇵 日本語 (JP)' },
      { code: 'kr', label: '🇰🇷 한국어 (KR)' },
      { code: 'en', label: '🇺🇸 English' },
    ];

    const targetLanguages = [
      { code: 'vi', label: '🇻🇳 Tiếng Việt' },
      { code: 'en', label: '🇺🇸 English' },
      { code: 'th', label: '🇹🇭 ไทย' },
    ];

    const handleTranslatePage = useCallback(() => {
      onTranslatePage?.({ sourceLang, targetLang });
    }, [onTranslatePage, sourceLang, targetLang]);

    const handleTranslateAll = useCallback(() => {
      onTranslateAll?.({ sourceLang, targetLang });
    }, [onTranslateAll, sourceLang, targetLang]);

    const handleAbort = useCallback(() => {
      onAbort?.();
    }, [onAbort]);

    return (
      <div className="codenova-toolbar">
        <div className="codenova-language-selector">
          <select
            value={sourceLang}
            onChange={(e) => setSourceLang(e.target.value)}
            className="codenova-select"
            disabled={isLoading}
          >
            {languages.map((lang) => (
              <option key={lang.code} value={lang.code}>
                {lang.label}
              </option>
            ))}
          </select>
          <div className="codenova-arrow-icon">→</div>

          <select
            value={targetLang}
            onChange={(e) => setTargetLang(e.target.value)}
            className="codenova-select"
            disabled={isLoading}
          >
            {targetLanguages.map((lang) => (
              <option key={lang.code} value={lang.code}>
                {lang.label}
              </option>
            ))}
          </select>
        </div>

        <div className="codenova-button-group">
          {isLoading ? (
            <button
              onClick={handleAbort}
              className="codenova-btn codenova-btn-abort"
            >
              <svg className="codenova-btn-icon" viewBox="0 0 24 24" fill="none">
                <rect
                  x="6"
                  y="6"
                  width="12"
                  height="12"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
              <span>Dừng lại</span>
            </button>
          ) : (
            <>
              <button
                onClick={handleTranslatePage}
                disabled={isLoading}
                className="codenova-btn codenova-btn-primary"
              >
                <svg className="codenova-btn-icon" viewBox="0 0 24 24" fill="none">
                  <path
                    d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
                <span>Trang này</span>
              </button>

              <button
                onClick={handleTranslateAll}
                disabled={isLoading}
                className="codenova-btn codenova-btn-secondary"
              >
                <svg className="codenova-btn-icon" viewBox="0 0 24 24" fill="none">
                  <rect
                    x="3"
                    y="3"
                    width="7"
                    height="7"
                    stroke="currentColor"
                    strokeWidth="2"
                  />
                  <rect
                    x="14"
                    y="3"
                    width="7"
                    height="7"
                    stroke="currentColor"
                    strokeWidth="2"
                  />
                  <rect
                    x="14"
                    y="14"
                    width="7"
                    height="7"
                    stroke="currentColor"
                    strokeWidth="2"
                  />
                  <rect
                    x="3"
                    y="14"
                    width="7"
                    height="7"
                    stroke="currentColor"
                    strokeWidth="2"
                  />
                </svg>
                <span>Toàn bộ</span>
              </button>
              <button
                onClick={() => onTranslateSelected?.({ sourceLang, targetLang })}
                disabled={isLoading || selectedCount === 0}
                className="codenova-btn codenova-btn-ghost"
                title={selectedCount === 0 ? 'Chưa chọn ảnh' : `Dịch ${selectedCount} ảnh đã chọn`}
              >
                <svg className="codenova-btn-icon" viewBox="0 0 24 24" fill="none">
                  <path d="M4 6h16M4 12h10M4 18h16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                <span>Đã chọn</span>
              </button>
            </>
          )}
        </div>
      </div>
    );
  }
);

ActionToolbar.displayName = 'ActionToolbar';