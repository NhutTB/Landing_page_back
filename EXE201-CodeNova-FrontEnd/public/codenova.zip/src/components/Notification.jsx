// ====== components/Notification.jsx (Redesigned) ======
import React, { useEffect, useState } from 'react';

export const Notification = React.memo(
  ({ message, type = 'info', onClose, duration = 3000 }) => {
    const [isClosing, setIsClosing] = useState(false);

    useEffect(() => {
      const timer = setTimeout(() => {
        handleClose();
      }, duration);
      return () => clearTimeout(timer);
    }, [duration]);

    const handleClose = () => {
      setIsClosing(true);
      setTimeout(() => {
        onClose();
      }, 300);
    };

    const icons = {
      info: (
        <svg viewBox="0 0 24 24" fill="none">
          <circle cx="12" cy="12" r="10" fill="currentColor" />
          <path
            d="M12 16v-4m0-4h.01"
            stroke="white"
            strokeWidth="2"
            strokeLinecap="round"
          />
        </svg>
      ),
      success: (
        <svg viewBox="0 0 24 24" fill="none">
          <circle cx="12" cy="12" r="10" fill="currentColor" />
          <path
            d="M9 12l2 2 4-4"
            stroke="white"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      ),
      error: (
        <svg viewBox="0 0 24 24" fill="none">
          <circle cx="12" cy="12" r="10" fill="currentColor" />
          <path
            d="M15 9l-6 6m0-6l6 6"
            stroke="white"
            strokeWidth="2"
            strokeLinecap="round"
          />
        </svg>
      ),
      warning: (
        <svg viewBox="0 0 24 24" fill="none">
          <path
            d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"
            fill="currentColor"
          />
          <path
            d="M12 9v4m0 4h.01"
            stroke="white"
            strokeWidth="2"
            strokeLinecap="round"
          />
        </svg>
      ),
    };

    return (
      <div className={`codenova-notification ${isClosing ? 'closing' : ''}`}>
        <div className={`codenova-notification-box ${type}`}>
          <div className={`codenova-notification-icon ${type}`}>
            {icons[type]}
          </div>
          <div className="codenova-notification-content">
            <p className="codenova-notification-text">{message}</p>
          </div>
          <button
            className="codenova-notification-close"
            onClick={handleClose}
          >
            <svg viewBox="0 0 24 24" fill="none">
              <path
                d="M18 6L6 18M6 6l12 12"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
              />
            </svg>
          </button>
          <div className="codenova-notification-progress">
            <div
              className="codenova-notification-progress-bar"
              style={{
                animationDuration: `${duration}ms`,
                animationName: 'notificationProgress',
              }}
            />
          </div>
        </div>
      </div>
    );
  }
);

Notification.displayName = 'Notification';