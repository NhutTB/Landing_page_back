// ====== components/tabs/AdvancedTab.jsx ======
import React, { useState } from 'react';
import { AlignLeft, AlignCenter, AlignRight } from 'lucide-react';
import { COLORS } from '../../constants/colors';

export function AdvancedTab() {
  const [alignment, setAlignment] = useState('left');
  const [lineHeight, setLineHeight] = useState(1.2);
  const [quality, setQuality] = useState('medium');

  return (
    <div className="space-y-4 animate-fadeIn">
      <div>
        <label className="text-xs font-semibold block mb-2" style={{ color: COLORS.textPrimary }}>
          Canh lề
        </label>
        <div className="flex gap-2">
          {[
            { value: 'left', icon: AlignLeft },
            { value: 'center', icon: AlignCenter },
            { value: 'right', icon: AlignRight },
          ].map(({ value, icon: Icon }) => (
            <button
              key={value}
              onClick={() => setAlignment(value)}
              className="flex-1 p-2 rounded border transition-all duration-200 flex items-center justify-center hover:shadow-md active:scale-95"
              style={{
                borderColor: alignment === value ? COLORS.primary : COLORS.border,
                backgroundColor: alignment === value ? COLORS.primaryLight : 'transparent',
              }}
            >
              <Icon size={16} style={{ color: alignment === value ? COLORS.primary : COLORS.textSecondary }} />
            </button>
          ))}
        </div>
      </div>

      <div>
        <label className="text-xs font-semibold" style={{ color: COLORS.textPrimary }}>
          Giãn dòng: {lineHeight.toFixed(1)}
        </label>
        <input
          type="range"
          min="0.8"
          max="2"
          step="0.1"
          value={lineHeight}
          onChange={(e) => setLineHeight(Number(e.target.value))}
          className="w-full mt-1"
        />
      </div>

      <div>
        <label className="text-xs font-semibold block mb-2" style={{ color: COLORS.textPrimary }}>
          Chất lượng Inpainting
        </label>
        <select
          value={quality}
          onChange={(e) => setQuality(e.target.value)}
          className="w-full px-2 py-1 border rounded text-sm focus:outline-none"
          style={{
            borderColor: COLORS.border,
            backgroundColor: COLORS.surface,
            color: COLORS.textPrimary,
          }}
        >
          <option value="low">Thấp</option>
          <option value="medium">Trung bình</option>
          <option value="high">Cao</option>
        </select>
      </div>
    </div>
  );
}
