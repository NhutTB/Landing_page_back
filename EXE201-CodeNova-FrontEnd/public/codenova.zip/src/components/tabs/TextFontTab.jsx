import React, { useState } from 'react';
import { Bold, Palette } from 'lucide-react';
import { COLORS } from '../../constants/colors';

export function TextFontTab({ image }) {
  const [texts, setTexts] = useState(image.texts || []);
  const [selectedFont, setSelectedFont] = useState('Arial');
  const [fontSize, setFontSize] = useState(16);
  const [isBold, setIsBold] = useState(false);
  const [textColor, setTextColor] = useState('#000000');
  const [fontSearch, setFontSearch] = useState('');

  const fonts = ['Arial', 'Segoe UI', 'Times New Roman', 'Georgia', 'Courier New', 'Verdana', 'Comic Sans MS'];
  const filteredFonts = fonts.filter(f =>
    f.toLowerCase().includes(fontSearch.toLowerCase())
  );

  return (
    <div className="space-y-4">
      {/* Text List */}
      <div className="space-y-2 animate-fadeIn">
        <label className="text-xs font-semibold" style={{ color: COLORS.textPrimary }}>
          Danh sách text ({texts.length})
        </label>
        <div className="space-y-2 max-h-40 overflow-y-auto">
          {texts.length === 0 ? (
            <p className="text-xs text-center py-4" style={{ color: COLORS.textTertiary }}>
              Chưa có text nào
            </p>
          ) : (
            texts.map((text, idx) => (
              <div
                key={idx}
                className="p-2 rounded border transition-all duration-200 hover:border-blue-400"
                style={{ borderColor: COLORS.border }}
              >
                <p className="text-xs" style={{ color: COLORS.textTertiary }}>
                  {text.original}
                </p>
                <input
                  type="text"
                  value={text.translated}
                  onChange={(e) => {
                    const newTexts = [...texts];
                    newTexts[idx].translated = e.target.value;
                    setTexts(newTexts);
                  }}
                  className="w-full mt-1 px-2 py-1 border rounded text-sm focus:outline-none focus:ring-2 transition-all"
                  style={{
                    borderColor: COLORS.border,
                    color: COLORS.textPrimary,
                  }}
                  placeholder="Nhập bản dịch..."
                />
              </div>
            ))
          )}
        </div>
      </div>

      {/* Font Picker */}
      <div className="space-y-2 animate-slideInLeft" style={{ animationDelay: '100ms' }}>
        <label className="text-xs font-semibold" style={{ color: COLORS.textPrimary }}>
          Chọn font
        </label>
        <input
          type="text"
          placeholder="Tìm kiếm font..."
          value={fontSearch}
          onChange={(e) => setFontSearch(e.target.value)}
          className="w-full px-2 py-1 border rounded text-sm focus:outline-none focus:ring-2"
          style={{
            borderColor: COLORS.border,
            color: COLORS.textPrimary,
            backgroundColor: COLORS.surface,
          }}
        />
        <div className="grid grid-cols-2 gap-2 max-h-24 overflow-y-auto">
          {filteredFonts.map(font => (
            <div
              key={font}
              onClick={() => setSelectedFont(font)}
              className="p-2 rounded border cursor-pointer transition-all duration-200 hover:shadow-md"
              style={{
                borderColor: selectedFont === font ? COLORS.primary : COLORS.border,
                backgroundColor: selectedFont === font ? COLORS.primaryLight : COLORS.surface,
              }}
            >
              <p style={{ fontFamily: font, fontSize: '12px' }}>Mẫu</p>
              <p style={{ color: COLORS.textTertiary, fontSize: '10px' }}>{font}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Font Controls */}
      <div className="space-y-3 animate-slideInLeft" style={{ animationDelay: '200ms' }}>
        <div>
          <label className="text-xs font-semibold" style={{ color: COLORS.textPrimary }}>
            Kích thước: {fontSize}px
          </label>
          <input
            type="range"
            min="8"
            max="32"
            value={fontSize}
            onChange={(e) => setFontSize(Number(e.target.value))}
            className="w-full mt-1"
          />
        </div>

        <div className="flex gap-2">
          <button
            onClick={() => setIsBold(!isBold)}
            className="flex-1 p-2 rounded border transition-all duration-300 flex items-center justify-center gap-1 text-xs hover:shadow-md active:scale-95"
            style={{
              borderColor: isBold ? COLORS.primary : COLORS.border,
              backgroundColor: isBold ? COLORS.primaryLight : 'transparent',
              color: COLORS.textPrimary,
            }}
          >
            <Bold size={14} /> Bold
          </button>
          <div
            className="flex-1 flex items-center gap-1 px-2 py-1 border rounded"
            style={{ borderColor: COLORS.border }}
          >
            <Palette size={14} style={{ color: COLORS.textSecondary }} />
            <input
              type="color"
              value={textColor}
              onChange={(e) => setTextColor(e.target.value)}
              className="w-full h-6 cursor-pointer"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
