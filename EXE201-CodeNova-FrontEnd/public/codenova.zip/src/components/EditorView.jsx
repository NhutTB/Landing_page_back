// ====== components/EditorView.jsx (Enhanced) ======
import React, { useState, useCallback } from 'react';
import { ChevronLeft, Eye, Check, Download, RotateCcw, ZoomIn, ZoomOut } from 'lucide-react';
import { TextFontTab } from './tabs/TextFontTab';
import { AdvancedTab } from './tabs/AdvancedTab';

export const EditorView = React.memo(({ image, onBack, onSave }) => {
  const [activeTab, setActiveTab] = useState('text');
  const [isSaving, setIsSaving] = useState(false);
  const [zoom, setZoom] = useState(100);
  const [showPreview, setShowPreview] = useState(false);

  const handleSave = useCallback(async () => {
    setIsSaving(true);
    try {
      await onSave(image);
    } finally {
      setIsSaving(false);
    }
  }, [image, onSave]);

  const handleZoomIn = () => setZoom(prev => Math.min(prev + 10, 200));
  const handleZoomOut = () => setZoom(prev => Math.max(prev - 10, 50));
  const handleResetZoom = () => setZoom(100);

  const tabs = [
    { id: 'text', label: 'Text & Font', icon: '✏️' },
    { id: 'advanced', label: 'Nâng cao', icon: '⚙️' },
  ];

  return (
    <div className="h-full flex flex-col bg-gradient-to-br from-white via-slate-50/30 to-white backdrop-blur-sm animate-fadeIn">
      {/* Header - Breadcrumb */}
      <div className="px-4 py-3 border-b border-slate-200 bg-gradient-to-r from-white to-sky-50/30 animate-slideDown">
        <button
          onClick={onBack}
          className="group flex items-center gap-2 text-sm text-sky-600 hover:text-sky-700 font-medium transition-all duration-300 hover:gap-3"
        >
          <ChevronLeft 
            size={18} 
            className="group-hover:-translate-x-1 transition-transform" 
          />
          <span>Quay lại danh sách</span>
        </button>
        
        {/* Image Info */}
        <div className="mt-2 flex items-center gap-2">
          <div className="flex-1">
            <h3 className="font-semibold text-slate-700 truncate">{image.name}</h3>
            <p className="text-xs text-slate-400">
              {image.width} × {image.height} px
            </p>
          </div>
          
          {/* Status Badge */}
          <div className={`px-2 py-1 rounded-full text-xs font-medium ${
            image.status === 'done' 
              ? 'bg-emerald-100 text-emerald-700' 
              : 'bg-sky-100 text-sky-700'
          }`}>
            {image.status === 'done' ? '✓ Hoàn thành' : '⏳ Đang xử lý'}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left - Image Preview */}
        <div className="flex-[55%] p-4 border-r border-slate-200 overflow-auto bg-gradient-to-br from-slate-50/50 to-white">
          <div className="space-y-3">
            {/* Zoom Controls */}
            <div className="flex items-center justify-between bg-white rounded-lg p-2 shadow-sm border border-slate-200 animate-slideDown">
              <div className="flex items-center gap-1">
                <button
                  onClick={handleZoomOut}
                  className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-600 transition-all duration-200 hover:scale-110 active:scale-95"
                  title="Thu nhỏ"
                >
                  <ZoomOut size={16} />
                </button>
                <span className="px-3 py-1 text-xs font-medium text-slate-600 min-w-[60px] text-center">
                  {zoom}%
                </span>
                <button
                  onClick={handleZoomIn}
                  className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-600 transition-all duration-200 hover:scale-110 active:scale-95"
                  title="Phóng to"
                >
                  <ZoomIn size={16} />
                </button>
                <button
                  onClick={handleResetZoom}
                  className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-600 transition-all duration-200 hover:scale-110 active:scale-95 ml-1"
                  title="Đặt lại"
                >
                  <RotateCcw size={16} />
                </button>
              </div>

              <button
                onClick={() => setShowPreview(!showPreview)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all duration-200 hover:scale-105 active:scale-95 ${
                  showPreview
                    ? 'bg-sky-500 text-white shadow-md'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {showPreview ? '📝 Chỉnh sửa' : '👁️ Xem trước'}
              </button>
            </div>

            {/* Image Container */}
            <div className="relative bg-white rounded-xl border-2 border-slate-200 shadow-lg overflow-hidden animate-scaleIn">
              {/* Checkerboard Background */}
              <div className="absolute inset-0 opacity-5 bg-[linear-gradient(45deg,#000_25%,transparent_25%,transparent_75%,#000_75%,#000),linear-gradient(45deg,#000_25%,transparent_25%,transparent_75%,#000_75%,#000)] bg-[length:20px_20px] bg-[position:0_0,10px_10px]" />
              
              {/* Image */}
              <div className="relative flex items-center justify-center p-4 min-h-[400px]">
                <img
                  src={image.thumb}
                  alt={image.name}
                  className="max-w-full h-auto transition-all duration-500 hover:scale-[1.02]"
                  style={{ 
                    transform: `scale(${zoom / 100})`,
                    filter: showPreview ? 'none' : 'brightness(0.98)',
                  }}
                />
                
                {/* Preview Overlay */}
                {showPreview && (
                  <div className="absolute inset-0 bg-gradient-to-t from-black/10 to-transparent pointer-events-none animate-fadeIn" />
                )}
              </div>

              {/* Corner Decorations */}
              <div className="absolute top-2 left-2 w-4 h-4 border-l-2 border-t-2 border-sky-400 opacity-50" />
              <div className="absolute top-2 right-2 w-4 h-4 border-r-2 border-t-2 border-sky-400 opacity-50" />
              <div className="absolute bottom-2 left-2 w-4 h-4 border-l-2 border-b-2 border-sky-400 opacity-50" />
              <div className="absolute bottom-2 right-2 w-4 h-4 border-r-2 border-b-2 border-sky-400 opacity-50" />
            </div>
          </div>
        </div>

        {/* Right - Controls */}
        <div className="flex-[45%] flex flex-col bg-white">
          {/* Tabs */}
          <div className="flex gap-1 p-3 border-b border-slate-200 bg-gradient-to-r from-slate-50/50 to-white animate-slideDown delay-75">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex-1 px-4 py-2.5 text-sm font-medium rounded-lg transition-all duration-300 relative overflow-hidden group ${
                  activeTab === tab.id
                    ? 'text-white bg-gradient-to-r from-sky-500 to-blue-500 shadow-md'
                    : 'text-slate-600 hover:text-sky-600 hover:bg-sky-50'
                }`}
              >
                {/* Ripple Effect */}
                <span className="absolute inset-0 bg-white opacity-0 group-hover:opacity-10 transition-opacity" />
                
                <span className="relative flex items-center justify-center gap-2">
                  <span>{tab.icon}</span>
                  <span>{tab.label}</span>
                </span>

                {/* Active Indicator */}
                {activeTab === tab.id && (
                  <div className="absolute bottom-0 left-0 right-0 h-1 bg-white rounded-t-full animate-slideUp" />
                )}
              </button>
            ))}
          </div>

          {/* Tab Content */}
          <div className="flex-1 overflow-y-auto p-4">
            <div className={`${activeTab === 'text' ? 'animate-slideInLeft' : 'animate-slideInRight'}`}>
              {activeTab === 'text' ? (
                <TextFontTab image={image} />
              ) : (
                <AdvancedTab />
              )}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="p-4 border-t border-slate-200 bg-gradient-to-r from-slate-50/50 to-white space-y-2 animate-slideUp">
            {/* Preview Button */}
            <button
              onClick={() => setShowPreview(!showPreview)}
              className="w-full px-4 py-2.5 rounded-xl text-sm font-medium border-2 border-slate-200 bg-white text-slate-700 hover:bg-slate-50 hover:border-slate-300 hover:shadow-md active:scale-[0.98] transition-all duration-300 flex items-center justify-center gap-2 group"
            >
              <Eye size={16} className="group-hover:scale-110 transition-transform" />
              <span>Xem trước kết quả</span>
            </button>

            {/* Save Buttons */}
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={handleSave}
                disabled={isSaving}
                className={`px-4 py-2.5 rounded-xl text-sm font-medium text-white flex items-center justify-center gap-2 transition-all duration-300 relative overflow-hidden group ${
                  isSaving
                    ? 'bg-gradient-to-r from-sky-400 to-blue-400 cursor-wait opacity-80'
                    : 'bg-gradient-to-r from-sky-500 via-blue-500 to-indigo-500 hover:shadow-xl hover:scale-[1.02] active:scale-[0.98] shadow-lg'
                }`}
              >
                {/* Shimmer Effect */}
                {!isSaving && (
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
                )}

                {isSaving ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Đang lưu...</span>
                  </>
                ) : (
                  <>
                    <Check size={16} />
                    <span>Áp dụng</span>
                  </>
                )}
              </button>

              <button
                disabled={isSaving}
                className="px-4 py-2.5 rounded-xl text-sm font-medium border-2 border-slate-200 bg-white text-slate-700 hover:bg-gradient-to-br hover:from-slate-50 hover:to-white hover:border-slate-300 hover:shadow-lg active:scale-[0.98] transition-all duration-300 flex items-center justify-center gap-2 group"
              >
                <Download size={16} className="group-hover:translate-y-0.5 transition-transform" />
                <span>Tải về</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
});

EditorView.displayName = 'EditorView';