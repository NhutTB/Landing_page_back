// ====== components/PageListView.jsx (Redesigned) ======
import React from 'react';
import { EmptyState } from './EmptyState';

export const PageListView = React.memo(
  ({ images, isLoading, onEditImage, onDeleteImage, onTranslateImage, selectedIds = new Set(), onSelectionChange }) => {
    // selectedIds is a Set managed by parent (SidePanel)

    const toggleSelect = (id) => {
      const isSelected = selectedIds.has(id);
      onSelectionChange?.(id, !isSelected);
    };

    const selectAll = () => {
      const allSelected = images.length > 0 && images.every(img => selectedIds.has(img.id));
      if (allSelected) {
        // Deselect all
        images.forEach(img => onSelectionChange?.(img.id, false));
      } else {
        // Select all
        images.forEach(img => onSelectionChange?.(img.id, true));
      }
    };

    const isAllSelected = images.length > 0 && images.every(img => selectedIds.has(img.id));

    if (isLoading || images.length === 0) {
      return <EmptyState isLoading={isLoading} />;
    }

    return (
      <div className="codenova-list-container">
        <div className="codenova-list-header">
          <button onClick={selectAll} className="codenova-select-all">
            <div className={`codenova-checkbox ${isAllSelected ? 'checked' : ''}`}>
              {isAllSelected && (
                <svg
                  className="codenova-checkbox-icon"
                  viewBox="0 0 24 24"
                  fill="none"
                >
                  <path
                    d="M20 6L9 17l-5-5"
                    stroke="currentColor"
                    strokeWidth="3"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              )}
            </div>
            <span>
              {selectedIds.size > 0
                ? `${selectedIds.size} được chọn`
                : 'Chọn ảnh'}
            </span>
          </button>
          <span className="codenova-image-count">{images.length} ảnh</span>
        </div>

        <div className="codenova-list-items">
          {images.map((img, index) => (
            <div
              key={img.id}
              className={`codenova-image-item ${
                selectedIds.has(img.id) ? 'selected' : ''
              }`}
              onClick={() => toggleSelect(img.id)}
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <div className="codenova-image-checkbox-wrapper">
                <div
                  className={`codenova-checkbox ${
                    selectedIds.has(img.id) ? 'checked' : ''
                  }`}
                >
                  {selectedIds.has(img.id) && (
                    <svg
                      className="codenova-checkbox-icon"
                      viewBox="0 0 24 24"
                      fill="none"
                    >
                      <path
                        d="M20 6L9 17l-5-5"
                        stroke="currentColor"
                        strokeWidth="3"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                  )}
                </div>
              </div>

              <div className="codenova-image-thumb">
                <img src={img.thumb} alt={img.name} />
                <div className={`codenova-status-badge ${img.status}`}>
                  {img.status === 'done' && '✓'}
                  {img.status === 'error' && '✗'}
                  {img.status === 'pending' && '⋯'}
                </div>
              </div>

              <div className="codenova-image-info">
                <div className="codenova-image-name">{img.name}</div>
                <div className={`codenova-image-status ${img.status}`}>
                  {img.status === 'pending' && 'Chờ xử lý'}
                  {img.status === 'queued' && 'Hàng đợi'}
                  {img.status === 'translating' && 'Đang dịch'}
                  {img.status === 'done' && 'Hoàn thành'}
                  {img.status === 'error' && 'Lỗi'}
                </div>
                {(img.width || img.height) && (
                  <div className="codenova-image-meta">
                    {img.width} × {img.height}
                    {img.duration && ` • ${img.duration}s`}
                  </div>
                )}
              </div>

              <div className="codenova-image-actions">
                <button
                  className="codenova-action-btn"
                  onClick={(e) => {
                    e.stopPropagation();
                    onTranslateImage?.(img.id);
                  }}
                  title="Dịch ảnh này"
                >
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                    <path
                      d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </button>
                <button
                  className="codenova-action-btn"
                  onClick={(e) => {
                    e.stopPropagation();
                    onEditImage(img.id);
                  }}
                  title="Chỉnh sửa"
                >
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                    <path
                      d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <path
                      d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </button>
                <button
                  className="codenova-action-btn delete"
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeleteImage(img.id);
                  }}
                  title="Xóa"
                >
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                    <path
                      d="M3 6h18M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }
);

PageListView.displayName = 'PageListView';