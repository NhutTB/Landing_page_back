// ====== src/components/Header.jsx ======
import React from 'react';

export const Header = React.memo(({ onPin, onClose, isPinned, credit = 0 }) => {
  return (
    <div className="codenova-header">
      <div className="codenova-header-content">
        <div className="codenova-logo">
          {/* SVG Logo cũ của bạn */}
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
            <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M2 17L12 22L22 17" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M2 12L12 17L22 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
        <div className="codenova-header-text">
          <h1 className="codenova-title">CODENOVA</h1>
          
          {/* 🚀 PHẦN QUAN TRỌNG: HIỂN THỊ CREDIT Ở ĐÂY */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '4px', marginTop: '2px' }}>
            <span style={{ 
              fontSize: '11px', 
              padding: '2px 8px', 
              background: '#eff6ff', // Xanh nhạt
              color: '#2563eb',      // Xanh đậm
              borderRadius: '4px', 
              fontWeight: '700',
              border: '1px solid #dbeafe'
            }}>
              💎 {credit !== null && credit !== undefined ? credit.toLocaleString() : '...'}
            </span>
          </div>

        </div>
      </div>
      <div className="codenova-header-actions">
        <button
          className={`codenova-icon-btn ${isPinned ? 'active' : ''}`}
          onClick={onPin}
          title={isPinned ? 'Gỡ ghim Panel' : 'Ghim Panel'}
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
            <path d="M16 12L21 7M21 7L16 2M21 7H9" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" transform={isPinned ? 'rotate(45 12 12)' : ''}/>
          </svg>
        </button>
        <button
          className="codenova-icon-btn close-btn"
          onClick={onClose}
          title="Đóng"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
            <path d="M18 6L6 18M6 6L18 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </button>
      </div>
    </div>
  );
});

Header.displayName = 'Header';