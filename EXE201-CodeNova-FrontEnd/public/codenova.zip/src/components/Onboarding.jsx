// ====== components/Onboarding.jsx (Redesigned) ======
import React, { useState } from 'react';
import { Storage } from '../utils/storage';

export const Onboarding = React.memo(({ onComplete }) => {
  const [currentStep, setCurrentStep] = useState(0);

  const steps = [
    {
      title: '👋 Chào mừng đến CODENOVA',
      desc: 'Công cụ dịch truyện tự động bằng AI mạnh mẽ và dễ sử dụng',
      icon: '✨',
    },
    {
      title: '📖 Danh sách ảnh',
      desc: 'Chọn các ảnh bạn muốn dịch và xem trạng thái xử lý',
      icon: '🖼️',
    },
    {
      title: '⚡ Dịch trang',
      desc: 'Nhấn nút này để dịch toàn bộ ảnh trong trang một cách nhanh chóng',
      icon: '⚡',
    },
    {
      title: '✏️ Chỉnh sửa chi tiết',
      desc: 'Tùy chỉnh font, màu sắc và nội dung text theo ý muốn',
      icon: '✏️',
    },
    {
      title: '🚀 Sẵn sàng!',
      desc: 'Bạn đã sẵn sàng bắt đầu. Chúc bạn dịch vui vẻ!',
      icon: '🎉',
    },
  ];

  const step = steps[currentStep];
  const progress = ((currentStep + 1) / steps.length) * 100;

  const next = async () => {
    if (currentStep === steps.length - 1) {
      await Storage.set('onboardingCompleted', true);
      onComplete();
    } else {
      setCurrentStep(currentStep + 1);
    }
  };

  const skip = async () => {
    await Storage.set('onboardingCompleted', true);
    onComplete();
  };

  return (
    <div className="codenova-onboarding">
      <div className="codenova-onboarding-modal">
        <div className="codenova-onboarding-bg" />
        <div className="codenova-onboarding-content">
          <div className="codenova-onboarding-progress">
            <div
              className="codenova-onboarding-progress-fill"
              style={{ width: `${progress}%` }}
            />
          </div>

          <div className="codenova-onboarding-icon">{step.icon}</div>

          <h2 className="codenova-onboarding-title">{step.title}</h2>
          <p className="codenova-onboarding-description">{step.desc}</p>

          <div className="codenova-onboarding-dots">
            {steps.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrentStep(i)}
                className={`codenova-onboarding-dot ${
                  i === currentStep
                    ? 'active'
                    : i < currentStep
                    ? 'completed'
                    : ''
                }`}
              />
            ))}
          </div>

          <div className="codenova-onboarding-actions">
            {currentStep < steps.length - 1 && (
              <button
                onClick={skip}
                className="codenova-onboarding-btn codenova-onboarding-btn-secondary"
              >
                Bỏ qua
              </button>
            )}
            <button
              onClick={next}
              className="codenova-onboarding-btn codenova-onboarding-btn-primary"
            >
              {currentStep === steps.length - 1 ? 'Bắt đầu ngay' : 'Tiếp theo'}
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                <path
                  d="M5 12h14m-7-7l7 7-7 7"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
});

Onboarding.displayName = 'Onboarding';