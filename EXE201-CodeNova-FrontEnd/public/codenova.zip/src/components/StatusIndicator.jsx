import React from 'react';
import { Check, AlertCircle, Loader } from 'lucide-react';

export function StatusIndicator({ status, duration }) {
  const states = {
    pending: { color: 'text-slate-400', label: 'Chờ xử lý', icon: <div className="w-2 h-2 bg-slate-300 rounded-full" /> },
    queued: { color: 'text-sky-400', label: 'Hàng đợi', icon: <div className="w-2 h-2 bg-sky-400 rounded-full" /> },
    translating: { color: 'text-sky-500', label: 'Đang dịch', icon: <Loader size={12} className="animate-spin" /> },
    done: { color: 'text-emerald-500', label: 'Hoàn thành', icon: <Check size={12} /> },
    error: { color: 'text-rose-500', label: 'Lỗi', icon: <AlertCircle size={12} /> },
  };

  const s = states[status] || states.pending;

  return (
    <div className={`flex items-center gap-1.5 text-xs font-medium ${s.color} animate-fadeIn`}>
      {s.icon}
      <span>{s.label}</span>
      {duration && <span className="text-slate-400">• {duration}s</span>}
    </div>
  );
}
