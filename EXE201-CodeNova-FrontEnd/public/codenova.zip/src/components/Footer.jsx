import React from 'react';

function UserAvatar({ user }) {
  if (!user) return null;

  const initial = (user.display_name || user.email || 'U').charAt(0).toUpperCase();
  const emailHash = user.email ? Array.from(user.email).reduce((acc, char) => char.charCodeAt(0) + ((acc << 5) - acc), 0) : 0;
  const colors = ['#f87171', '#fb923c', '#fbbf24', '#a3e635', '#4ade80', '#34d399', '#2dd4bf', '#60a5fa', '#818cf8', '#c084fc'];
  const color = colors[Math.abs(emailHash) % colors.length];

  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
      <div
        title={user.email}
        style={{
          width: '28px',
          height: '28px',
          borderRadius: '50%',
          backgroundColor: color,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: 'white',
          fontSize: '14px',
          fontWeight: '600',
          textTransform: 'uppercase',
        }}
      >
        {initial}
      </div>
      <span style={{ fontSize: '12px', color: '#475569', fontWeight: '500' }}>
        {user.display_name || 'Người dùng'}
      </span>
    </div>
  );
}

export function Footer({ stats, onRefresh, user }) {
  return (
    <footer
      style={{
        padding: '8px 16px',
        borderTop: '1px solid #e5e7eb',
        background: '#ffffff',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        fontSize: '12px',
        color: '#64748b',
        flexShrink: 0,
      }}
    >
      <div style={{ flex: 1 }}>
        <UserAvatar user={user} />
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
        <span>
          Đã chọn: {stats.selected}/{stats.total}
        </span>
        <button
          onClick={onRefresh}
          title="Làm mới danh sách ảnh"
          style={{
            background: 'none',
            border: 'none',
            cursor: 'pointer',
            padding: '4px',
            borderRadius: '4px',
          }}
        >
          🔄
        </button>
      </div>
    </footer>
  );
}