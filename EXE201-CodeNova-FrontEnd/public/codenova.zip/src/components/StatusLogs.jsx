// ====== components/StatusLogs.jsx (Redesigned) ======
import React from 'react';

export const StatusLogs = React.memo(({ isExpanded, onToggle, logs, progress }) => {
  const percent = progress.total
    ? Math.round((progress.current / progress.total) * 100)
    : 0;

  return (
    <div className="codenova-status-logs">
      <div className="codenova-logs-header" onClick={onToggle}>
        <div className="codenova-logs-title">
          <svg viewBox="0 0 24 24" fill="none">
            <path
              d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
          <span>Tiến trình</span>
          {progress.total > 0 && (
            <span className="codenova-progress-badge">{percent}%</span>
          )}
        </div>
        <svg
          className={`codenova-logs-chevron ${isExpanded ? 'expanded' : ''}`}
          viewBox="0 0 24 24"
          fill="none"
        >
          <path
            d="M19 9l-7 7-7-7"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </div>

      <div
        className={`codenova-logs-content ${isExpanded ? 'expanded' : ''}`}
      >
        <div className="codenova-logs-inner">
          {progress.total > 0 && (
            <div className="codenova-progress-bar-container">
              <div className="codenova-progress-info">
                <span className="codenova-progress-text">
                  {progress.current} / {progress.total} ảnh
                </span>
                <span className="codenova-progress-percent">{percent}%</span>
              </div>
              <div className="codenova-progress-bar">
                <div
                  className="codenova-progress-fill"
                  style={{ width: `${percent}%` }}
                />
              </div>
            </div>
          )}

          <div className="codenova-logs-list">
            {logs.length === 0 ? (
              <div className="codenova-logs-empty">
                <svg viewBox="0 0 24 24" fill="none">
                  <circle
                    cx="12"
                    cy="12"
                    r="10"
                    stroke="currentColor"
                    strokeWidth="2"
                  />
                  <path
                    d="M12 6v6l4 2"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                  />
                </svg>
                <p className="codenova-logs-empty-text">
                  Chưa có hoạt động nào
                </p>
              </div>
            ) : (
              logs.map((log, i) => {
                const isSuccess = log.includes('✓');
                const isError = log.includes('✗');
                const type = isSuccess
                  ? 'success'
                  : isError
                  ? 'error'
                  : 'info';

                return (
                  <div key={i} className="codenova-log-item">
                    <svg
                      className={`codenova-log-icon ${type}`}
                      viewBox="0 0 24 24"
                      fill="none"
                    >
                      {isSuccess && (
                        <path
                          d="M20 6L9 17l-5-5"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      )}
                      {isError && (
                        <path
                          d="M18 6L6 18M6 6l12 12"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      )}
                      {!isSuccess && !isError && (
                        <circle
                          cx="12"
                          cy="12"
                          r="10"
                          stroke="currentColor"
                          strokeWidth="2"
                        />
                      )}
                    </svg>
                    <span className={`codenova-log-text ${type}`}>{log}</span>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
});

StatusLogs.displayName = 'StatusLogs';