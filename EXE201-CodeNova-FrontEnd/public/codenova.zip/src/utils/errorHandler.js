// ====== utils/errorHandler.js ======
export class ErrorHandler {
  static formatError(error) {
    if (typeof error === 'string') return error;
    if (error.message) return error.message;
    return 'Có lỗi không xác định xảy ra';
  }

  static isNetworkError(error) {
    return error.message.includes('Network') || 
           error.message.includes('CORS') ||
           error.message.includes('Failed to fetch');
  }

  static isTimeoutError(error) {
    return error.message.includes('timeout') ||
           error.message.includes('504') ||
           error.message.includes('Timeout');
  }

  static getUserMessage(error) {
    if (this.isNetworkError(error)) {
      return 'Lỗi kết nối. Vui lòng kiểm tra API server.';
    }
    if (this.isTimeoutError(error)) {
      return 'Yêu cầu hết thời gian. Thử lại sau.';
    }
    return this.formatError(error);
  }
}