// ====== utils/storage.js ======
const hasChromeAPI = (typeof chrome !== 'undefined') &&
                     (typeof chrome.storage !== 'undefined') &&
                     (typeof chrome.storage.local !== 'undefined');

export const Storage = {
  async set(key, value) {
    if (hasChromeAPI) {
      return new Promise((resolve, reject) => {
        try {
          chrome.storage.local.set({ [key]: value }, () => {
            if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
            resolve();
          });
        } catch (err) {
          reject(err);
        }
      });
    }
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return Promise.resolve();
    } catch (err) {
      return Promise.reject(err);
    }
  },

  async get(key) {
    if (hasChromeAPI) {
      return new Promise((resolve, reject) => {
        try {
          chrome.storage.local.get([key], (result) => {
            if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
            resolve(result[key]);
          });
        } catch (err) {
          reject(err);
        }
      });
    }
    try {
      const value = localStorage.getItem(key);
      return Promise.resolve(value ? JSON.parse(value) : undefined);
    } catch (err) {
      return Promise.reject(err);
    }
  },

  async remove(key) {
    if (hasChromeAPI) {
      return new Promise((resolve, reject) => {
        try {
          chrome.storage.local.remove([key], () => {
            if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
            resolve();
          });
        } catch (err) {
          reject(err);
        }
      });
    }
    try {
      localStorage.removeItem(key);
      return Promise.resolve();
    } catch (err) {
      return Promise.reject(err);
    }
  },

  async clear() {
    if (hasChromeAPI) {
      return new Promise((resolve, reject) => {
        try {
          chrome.storage.local.clear(() => {
            if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
            resolve();
          });
        } catch (err) {
          reject(err);
        }
      });
    }
    try {
      localStorage.clear();
      return Promise.resolve();
    } catch (err) {
      return Promise.reject(err);
    }
  },
};
