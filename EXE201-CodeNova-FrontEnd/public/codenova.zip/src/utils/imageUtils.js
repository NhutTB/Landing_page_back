// ====== utils/imageUtils.js ======
export const imageUtils = {
  getImageUrl(image) {
    return image.src || image.thumb || '';
  },

  getThumbnail(image, size = 'small') {
    const url = this.getImageUrl(image);
    // Có thể thêm logic resize thumbnail ở đây
    return url;
  },

  isValidImageStatus(status) {
    return ['pending', 'queued', 'translating', 'done', 'error'].includes(status);
  },

  updateImageStatus(images, imageId, newStatus) {
    return images.map(img => 
      img.id === imageId ? { ...img, status: newStatus } : img
    );
  },

  getStatusLabel(status) {
    const labels = {
      pending: 'Chờ xử lý',
      queued: 'Hàng đợi',
      translating: 'Đang dịch',
      done: 'Hoàn thành',
      error: 'Lỗi',
    };
    return labels[status] || status;
  },
};
