import React from 'react';
import ReactDOM from 'react-dom/client';
import { SidePanel } from './components/SidePanel';

const root = document.getElementById('codenova-side-panel-root');
if (root) {
  const reactRoot = ReactDOM.createRoot(root);
  reactRoot.render(<SidePanel />);
}