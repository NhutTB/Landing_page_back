// ====== hooks/useKeyboard.js (New) ======
import { useEffect, useCallback } from 'react';

export function useKeyboard(handlers = {}, deps = []) {
  const handleKeyDown = useCallback((event) => {
    const { key, ctrlKey, metaKey, shiftKey, altKey } = event;
    const modifiers = { ctrl: ctrlKey || metaKey, shift: shiftKey, alt: altKey };

    // Build key combo string
    const combo = [
      modifiers.ctrl && 'ctrl',
      modifiers.shift && 'shift',
      modifiers.alt && 'alt',
      key.toLowerCase()
    ].filter(Boolean).join('+');

    // Check for handler
    const handler = handlers[combo] || handlers[key.toLowerCase()];
    if (handler) {
      event.preventDefault();
      handler(event);
    }
  }, [handlers, ...deps]);

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyDown]);
}