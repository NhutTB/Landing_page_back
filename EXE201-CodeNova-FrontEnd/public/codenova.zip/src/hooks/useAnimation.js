// ====== hooks/useAnimation.js (New) ======
import { useState, useEffect, useCallback } from 'react';

export function useAnimation(initialState = false) {
  const [isAnimating, setIsAnimating] = useState(initialState);
  const [animationClass, setAnimationClass] = useState('');

  const startAnimation = useCallback((className, duration = 300) => {
    setIsAnimating(true);
    setAnimationClass(className);
    
    const timer = setTimeout(() => {
      setIsAnimating(false);
      setAnimationClass('');
    }, duration);

    return () => clearTimeout(timer);
  }, []);

  const animate = useCallback((
    enterClass = 'animate-fadeIn',
    exitClass = 'animate-fadeOut',
    duration = 300
  ) => {
    return {
      enter: () => startAnimation(enterClass, duration),
      exit: () => startAnimation(exitClass, duration),
    };
  }, [startAnimation]);

  return {
    isAnimating,
    animationClass,
    startAnimation,
    animate,
  };
}