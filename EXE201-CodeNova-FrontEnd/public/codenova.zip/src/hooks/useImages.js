// ====== hooks/useImages.js (Fixed with Retry Logic) ======
import { useState, useEffect, useCallback } from 'react';

// A helper to transform the raw image data from content script into the format our app uses
const transformImage = (img, idx) => ({
  id: img.id ?? img.src ?? idx, // Use src as a fallback ID
  name: img.filename || `Image ${idx + 1}`,
  src: img.src,
  thumb: img.thumb || img.src,
  status: 'pending',
  width: img.width || 0,
  height: img.height || 0,
  texts: [],
  duration: 0,
});

// Helper to add a delay
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

export function useImages({ autoRefresh = false, refreshInterval = 30000 } = {}) {
  const [images, setImages] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const pingBackground = useCallback(async (retries = 3, delayMs = 100) => {
    for (let i = 0; i < retries; i++) {
      try {
        const response = await chrome.runtime.sendMessage({ action: 'PING' });
        if (response?.ok) {
          console.log('[useImages] Background script is active.');
          return true;
        }
      } catch (e) {
        if (i < retries - 1) {
          console.warn(`[useImages] Background ping failed, retrying... (${i + 1}/${retries})`);
          await delay(delayMs * (i + 1)); // Tăng dần thời gian chờ
        } else {
          console.error('[useImages] Background script is not responding.');
          return false;
        }
      }
    }
    return false;
  }, []); // ✅ Đã có mảng rỗng, rất tốt!

  const fetchImages = useCallback(async (options = {}) => {
    setLoading(true);
    setError(null);

    // 1. Đảm bảo background script đang hoạt động
    const isBackgroundReady = await pingBackground();
    if (!isBackgroundReady) {
      setError('Không thể kết nối đến background service. Vui lòng thử tải lại extension.');
      setLoading(false);
      return [];
    }

    // 2. Tiếp tục lấy danh sách ảnh với cơ chế retry
    const MAX_RETRIES = 5; // Giữ nguyên số lần thử
    const RETRY_DELAY = 300; // Tăng thời gian chờ ban đầu

    for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
      try {
        if (typeof chrome === 'undefined' || !chrome.runtime?.sendMessage) {
          throw new Error("Chrome runtime is not available.");
        }

        // Send message to background script to orchestrate image fetching
        const response = await chrome.runtime.sendMessage({
          action: 'FETCH_IMAGE_LIST_FROM_PANEL',
          minSize: options.minSize || 200,
        });

        if (chrome.runtime.lastError) {
          throw new Error(chrome.runtime.lastError.message);
        }
        
        if (response && response.ok && Array.isArray(response.images)) {
          const transformed = response.images.map(transformImage);
          setImages(transformed);
          setLoading(false);
          return transformed; // Success, exit the loop and function
        } else {
          throw new Error(response?.error || 'Phản hồi không hợp lệ từ background script.');
        }

      } catch (err) {
        // If it's the specific connection error and we haven't exhausted retries, wait and continue the loop
        if (err.message.includes('Receiving end does not exist') && attempt < MAX_RETRIES) {
          console.warn(`[useImages] Connection failed on attempt ${attempt}. Retrying in ${RETRY_DELAY}ms...`);
          await delay(RETRY_DELAY * attempt); // Tăng dần thời gian chờ
          continue; // Go to the next iteration
        }
        
        // If it's another error or the last retry failed, set the error state and break
        console.error(`[useImages] Error fetching images after ${attempt} attempts:`, err);
        setError(err.message);
        setImages([]);
        setLoading(false);
        return []; // Exit function with empty array
      }
    }
  }, [pingBackground]);

  // Effect to fetch images when the hook mounts
  useEffect(() => {
    fetchImages();
  }, [fetchImages]);

  return {
    images,
    setImages,
    loading,
    error,
    fetchImages,
  };
}