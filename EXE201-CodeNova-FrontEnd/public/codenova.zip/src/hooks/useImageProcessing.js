// ====== hooks/useImageProcessing.js ======
export function useImageProcessing() {
  // local check for chrome API (also available as window.hasChromeAPI from init script)
  const hasChromeAPI = (typeof chrome !== 'undefined') &&
                       (typeof chrome.runtime !== 'undefined') &&
                       (typeof chrome.runtime.sendMessage === 'function');

  const sendChromeMessage = (payload, signal) => {
    return new Promise((resolve, reject) => {
      try {
        if (!hasChromeAPI) return reject(new Error('Chrome runtime not available'));
        if (signal?.aborted) return reject(new DOMException('Aborted', 'AbortError'));

        chrome.runtime.sendMessage(payload, (response) => {
          if (chrome.runtime.lastError) {
            if (chrome.runtime.lastError.message.includes('aborted')) return reject(new DOMException('Aborted', 'AbortError'));
            return reject(new Error(chrome.runtime.lastError.message));
          }
          resolve(response);
        });
      } catch (err) {
        reject(err);
      }
    });
  };

  /**
   * images: array (can be blobs/base64/urls depending on your design)
   * apiUrl: backend endpoint used when not running as extension
   * signal: AbortSignal to cancel the operation
   */
  // images: array for batch; options: { image } to process a single image
  const processImages = async (images = [], apiUrl = 'http://localhost:7000', signal, options = {}) => {
      console.log('[useImageProcessing] Starting with:', { imageCount: images?.length, apiUrl, options });

      const messagePayload = {
        action: 'PROCESS_PAGE_IMAGES',
        apiUrl,
        source_language: options.source_language || 'ch', // Sử dụng ngôn ngữ từ options hoặc mặc định
        target_language: options.target_language || 'vi', // Sử dụng ngôn ngữ từ options hoặc mặc định
        // 🚀 Gửi toàn bộ danh sách ảnh cần xử lý
        images: images, 
      };

      console.log('[useImageProcessing] Sending message:', messagePayload);

    try {
      let response;
      if (hasChromeAPI) {
        // Use extension messaging
        response = await sendChromeMessage(messagePayload, signal); // Giờ đây sẽ nhận phản hồi 'started' ngay lập tức
      } else {
        // Fallback: call backend directly (useful for dev on web)
        // Expect your backend to accept JSON { images, source_language, target_language }
        const resp = await fetch(`${apiUrl.replace(/\/$/, '')}/process_images`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          signal, // Pass signal to fetch
          body: JSON.stringify({
            images,
            source_language: messagePayload.source_language,
            target_language: messagePayload.target_language,
          }),
        });
        response = await resp.json();
      }

      // Mong đợi một xác nhận ngay lập tức rằng tác vụ background đã bắt đầu
      // Background may respond differently for batch (started) vs single-image (immediate result)
      if (response && response.ok) {
        // If background returned a 'started' status for async batch
        if (response.status === 'started') return { ok: true, status: 'started' };
        // If background returned processing results (single-image or completed run), return them
        return response;
      }

      // Otherwise normalize error
      const errMsg = (response && response.error) ? response.error : 'Image processing failed';
      throw new Error(errMsg);
    } catch (err) {
      if (err.name === 'AbortError') {
        console.log('[useImageProcessing] Process aborted by user.');
        // Don't re-throw abort errors as they are intentional
      } else {
        console.error('[useImageProcessing] ❌ Error details:', {
          message: err.message,
          stack: err.stack,
          apiUrl: messagePayload.apiUrl,
          hasChromeAPI,
        });
        throw err; // Re-throw other errors to be handled by the caller
      }
    } finally {
      // setIsProcessing(false); // UI sẽ quản lý trạng thái này dựa trên các tin nhắn PROCESSING_COMPLETE
    }
  };

  const processSingleImage = async (image, apiUrl = 'http://localhost:7000', signal, source_language = 'ch', target_language = 'vi') => {
    console.log('[useImageProcessing] Starting single image processing:', { image, apiUrl, source_language, target_language });

    const messagePayload = {
      action: 'PROCESS_SINGLE_IMAGE',
      apiUrl,
      source_language,
      target_language,
      image,
    };

    console.log('[useImageProcessing] Sending single image message:', messagePayload);

    try {
      if (!hasChromeAPI) {
        throw new Error('Chức năng này yêu cầu môi trường extension.');
      }
      
      const response = await sendChromeMessage(messagePayload, signal);

      if (response && response.ok) {
        return response;
      } else {
        const errMsg = (response && response.error) ? response.error : 'Xử lý ảnh đơn thất bại';
        throw new Error(errMsg);
      }
    } catch (err) {
      console.error('[useImageProcessing] ❌ Error in single processing:', {
        message: err.message,
        stack: err.stack,
      });
      throw err;
    }
  };

  return { processImages, processSingleImage };
}
