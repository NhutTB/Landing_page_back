// ====== hooks/useImageQueue.js (New) ======
import { useState, useCallback, useRef } from 'react';

export function useImageQueue() {
  const [queue, setQueue] = useState([]);
  const [processing, setProcessing] = useState(false);
  const processingRef = useRef(false);

  const addToQueue = useCallback((images) => {
    setQueue(prev => [...prev, ...images.filter(img => 
      !prev.some(existing => existing.id === img.id)
    )]);
  }, []);

  const removeFromQueue = useCallback((imageId) => {
    setQueue(prev => prev.filter(img => img.id !== imageId));
  }, []);

  const clearQueue = useCallback(() => {
    setQueue([]);
  }, []);

  const processQueue = useCallback(async (processFn, batchSize = 3) => {
    if (processingRef.current || queue.length === 0) return;

    setProcessing(true);
    processingRef.current = true;

    const results = [];
    const batches = [];
    
    // Split into batches
    for (let i = 0; i < queue.length; i += batchSize) {
      batches.push(queue.slice(i, i + batchSize));
    }

    try {
      for (const batch of batches) {
        const batchPromises = batch.map(img => processFn(img));
        const batchResults = await Promise.allSettled(batchPromises);
        results.push(...batchResults);

        // Remove processed items from queue
        setQueue(prev => prev.filter(img => 
          !batch.some(b => b.id === img.id)
        ));
      }

      return results;
    } finally {
      setProcessing(false);
      processingRef.current = false;
    }
  }, [queue]);

  return {
    queue,
    processing,
    addToQueue,
    removeFromQueue,
    clearQueue,
    processQueue,
  };
}
