import { useState, useCallback, useEffect } from 'react';

export function useAbortController() {
  const [abortController, setAbortController] = useState(new AbortController());

  const newAbortController = useCallback(() => {
    const newController = new AbortController();
    setAbortController(newController);
    return newController;
  }, []);

  const abort = useCallback(() => {
    abortController.abort();
  }, [abortController]);

  // Cleanup: abort any pending request when the component unmounts
  useEffect(() => {
    return () => {
      abortController.abort();
    };
  }, [abortController]);

  return { abortController, newAbortController, abort };
}
