// ====== src/panel/inject-styles.js ======
export function injectStyles() {
  // Skip if not in extension context
  if (typeof chrome === 'undefined' || !chrome.runtime) {
    console.warn('[CODENOVA] Chrome runtime not available');
    return false;
  }

  // Check if already injected
  const existingLink = document.getElementById('codenova-styles');
  if (existingLink) {
    console.log('[CODENOVA] Styles already injected');
    return true;
  }

  try {
    const link = document.createElement('link');
    link.id = 'codenova-styles';
    link.rel = 'stylesheet';
    link.type = 'text/css';
    link.href = chrome.runtime.getURL('build/side-panel.css');
    
    link.onload = () => {
      console.log('[CODENOVA] ✅ Styles loaded successfully');
    };
    
    link.onerror = (e) => {
      console.error('[CODENOVA] ❌ Failed to load styles:', e);
    };
    
    document.head.appendChild(link);
    return true;
  } catch (error) {
    console.error('[CODENOVA] Error injecting styles:', error);
    return false;
  }
}

export function waitForStyles(timeout = 3000) {
  return new Promise((resolve) => {
    const startTime = Date.now();
    
    const checkStyles = () => {
      const link = document.getElementById('codenova-styles');
      if (!link) {
        if (Date.now() - startTime > timeout) {
          console.warn('[CODENOVA] Styles timeout');
          resolve(false);
          return;
        }
        setTimeout(checkStyles, 50);
        return;
      }

      // Check if stylesheet is loaded
      if (link.sheet) {
        console.log('[CODENOVA] Stylesheet ready, rules:', link.sheet.cssRules?.length);
        resolve(true);
      } else {
        if (Date.now() - startTime > timeout) {
          resolve(false);
          return;
        }
        setTimeout(checkStyles, 50);
      }
    };
    
    checkStyles();
  });
}