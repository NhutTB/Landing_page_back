import React from 'react';
import ReactDOM from 'react-dom/client';
import { SidePanel } from './SidePanel.jsx';
import { injectStyles, waitForStyles } from './inject-styles.js';
import './styles.css';
import './debug-styles.js'; 

console.log("[CODENOVA] Panel script loading...");

// Check if already initialized
if (window.__CODENOVA_PANEL_INITIALIZED__) {
  console.log('[CODENOVA] Panel already initialized, skipping.');
} else {
  window.__CODENOVA_PANEL_INITIALIZED__ = true;

  // Wait for DOM to be ready
  const initPanel = async () => {
    try {
      // Check if container exists (created by side-panel-init.js)
      let container = document.getElementById('codenova-side-panel-container');
      
      if (!container) {
        console.log('[CODENOVA] Container not found, creating it now...');
        container = document.createElement('div');
        container.id = 'codenova-side-panel-container';
        container.style.cssText = `
          position: fixed;
          top: 0;
          right: 0;
          width: 384px;
          height: 100vh;
          z-index: 2147483647;
        `;
        document.body.appendChild(container);
      }

      // Find or create root element
      let root = container.querySelector('#root');
      if (!root) {
        root = document.createElement('div');
        root.id = 'root';
        container.appendChild(root);
      }

      // Inject and wait for styles
      console.log('[CODENOVA] Injecting styles...');
      injectStyles();
      const stylesLoaded = await waitForStyles();
      
      if (!stylesLoaded) {
        console.warn('[CODENOVA] ⚠️ Styles may not be fully loaded');
      }

      console.log('[CODENOVA] Mounting React app...');
      const reactRoot = ReactDOM.createRoot(root);
      reactRoot.render(<SidePanel />);
      console.log('[CODENOVA] ✅ React mounted successfully');
    } catch (error) {
      console.error('[CODENOVA] ❌ Mount error:', error);
    }
  };

  // Initialize when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initPanel);
  } else {
    initPanel();
  }
}