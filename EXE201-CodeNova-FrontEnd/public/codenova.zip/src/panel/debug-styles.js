// ====== src/panel/debug-styles.js ======
export function debugStyles() {
  console.group('🔍 CODENOVA Styles Debug');
  
  // Check CSS link
  const cssLink = document.getElementById('codenova-styles');
  console.log('CSS Link element:', cssLink);
  console.log('CSS href:', cssLink?.href);
  
  // Check if CSS file exists
  if (cssLink) {
    fetch(cssLink.href)
      .then(res => {
        console.log('CSS file status:', res.status);
        return res.text();
      })
      .then(text => {
        console.log('CSS file size:', text.length, 'bytes');
        console.log('CSS preview:', text.substring(0, 200));
      })
      .catch(err => console.error('CSS fetch error:', err));
  }
  
  // Check computed styles
  const container = document.getElementById('codenova-side-panel-container');
  const panel = document.querySelector('.codenova-panel');
  
  if (container) {
    const containerStyles = window.getComputedStyle(container);
    console.log('Container computed styles:', {
      position: containerStyles.position,
      width: containerStyles.width,
      height: containerStyles.height,
      zIndex: containerStyles.zIndex,
      display: containerStyles.display,
    });
  }
  
  if (panel) {
    const panelStyles = window.getComputedStyle(panel);
    console.log('Panel computed styles:', {
      background: panelStyles.backgroundColor,
      width: panelStyles.width,
      position: panelStyles.position,
      zIndex: panelStyles.zIndex,
      display: panelStyles.display,
      flexDirection: panelStyles.flexDirection,
    });
  } else {
    console.error('❌ Panel element not found!');
  }
  
  console.groupEnd();
}

// Auto run after 1 second
setTimeout(debugStyles, 1000);