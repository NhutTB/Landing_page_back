// ====== panel/SidePanel.jsx (Redesigned) ======
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useImages } from '../hooks/useImages';
import { useAbortController } from '../hooks/useAbortController';
import { useImageProcessing } from '../hooks/useImageProcessing';
import { useNotification } from '../hooks/useNotification';
import { useKeyboard } from '../hooks/useKeyboard';
import { useImageQueue } from '../hooks/useImageQueue';
import { ErrorHandler } from '../utils/errorHandler';
import { Storage } from '../utils/storage';

import { Header } from '../components/Header';
import { ActionToolbar } from '../components/ActionToolbar';
import { PageListView } from '../components/PageListView';
import { EditorView } from '../components/EditorView';
import { StatusLogs } from '../components/StatusLogs';
import { Footer } from '../components/Footer';
import { Notification } from '../components/Notification';
import { Onboarding } from '../components/Onboarding';

export function SidePanel() {
  const [userCredit, setUserCredit] = useState(null); // State lưu credit
  const [selectedImageId, setSelectedImageId] = useState(null);
  const [selectedImageIds, setSelectedImageIds] = useState(new Set());
  const [logsExpanded, setLogsExpanded] = useState(false);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [isPanelPinned, setIsPanelPinned] = useState(false);
  const [processLog, setProcessLog] = useState([]);
  const [cssLoaded, setCssLoaded] = useState(false);
  const [realtimeProgress, setRealtimeProgress] = useState({ current: 0, total: 0, message: '' });
  const [user, setUser] = useState(null);
  const [isBackgroundProcessing, setIsBackgroundProcessing] = useState(false);

  const { images, setImages, loading, error, fetchImages } = useImages();
  const { processImages, processSingleImage } = useImageProcessing();
  const { abortController, newAbortController, abort } = useAbortController();
  const { notification, showNotification, clearNotification } = useNotification();
  const { queue, addToQueue, removeFromQueue } = useImageQueue();

  const selectedImage = useMemo(
    () => images.find(img => img.id === selectedImageId),
    [images, selectedImageId]
  );

  // Hàm lấy thông tin User và Credit từ Node.js Backend
  const fetchUserProfile = useCallback(async () => {
    try {
      // Lấy token từ storage
      const token = await Storage.get('token');
      if (!token) {
        console.log("Chưa có token, đặt credit = 0");
        setUserCredit(0);
        return;
      }

      console.log("Đang gửi yêu cầu lấy profile qua Background...");

      // Gọi qua Background Script để tránh lỗi Mixed Content
      const response = await new Promise((resolve) => {
        chrome.runtime.sendMessage(
          { action: 'GET_USER_PROFILE', token: token },
          (res) => resolve(res)
        );
      });

      if (response && response.ok && response.data) {
        const serverData = response.data;
        if (serverData.success && serverData.data) {
          console.log("✅ Lấy profile thành công. Credit:", serverData.data.credit_balance);
          
          setUser(serverData.data);
          // Cập nhật Credit (dùng nullish coalescing để tránh lỗi nếu backend trả về null)
          setUserCredit(serverData.data.credit_balance ?? 0); 
          
          // Lưu lại user mới nhất vào storage
          Storage.set('user', serverData.data);
        }
      } else {
        console.error("❌ Lỗi lấy Profile từ Background:", response?.error);
        // Nếu lỗi do token hết hạn (401), set credit về 0
        if (response?.status === 401) {
           setUserCredit(0);
        }
      }
    } catch (err) {
      console.error("Lỗi nghiêm trọng trong fetchUserProfile:", err);
      setUserCredit(0); // Fallback an toàn
    }
  }, []);

  // Gọi fetchUserProfile khi component mount
  useEffect(() => {
    fetchUserProfile();
  }, [fetchUserProfile]);

  const processingStats = useMemo(() => ({
    total: images.length,
    pending: images.filter(img => img.status === 'pending').length,
    done: images.filter(img => img.status === 'done').length,
    error: images.filter(img => img.status === 'error').length,
    selected: selectedImageIds.size,
  }), [images]);

  const addLog = useCallback((message, type = 'info') => {
    const timestamp = new Date().toLocaleTimeString('vi-VN', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
    const icon = type === 'success' ? '✓' : type === 'error' ? '✗' : 'ℹ';
    const logMessage = `[${timestamp}] ${icon} ${message}`;
    setProcessLog((prev) => [...prev, logMessage].slice(-15));
  }, []);

  // CSS Loading Check
  useEffect(() => {
    const checkCSS = () => {
      const link = document.getElementById('codenova-styles');
      if (link && link.sheet) {
        try {
          const rules = link.sheet.cssRules || link.sheet.rules;
          if (rules && rules.length > 0) {
            setCssLoaded(true);
            console.log('[CODENOVA] ✅ CSS verified:', rules.length, 'rules');
            return;
          }
        } catch (e) {
          console.warn('[CODENOVA] CSS check error:', e);
        }
      }
      setTimeout(checkCSS, 100);
    };
    setTimeout(checkCSS, 50);
  }, []);

  // Load Initial State
  useEffect(() => {
    const loadInitialState = async () => {
      try {
        const [onboardingCompleted, panelPinned, storedUser] = await Promise.all([
          Storage.get('onboardingCompleted'),
          Storage.get('panelPinned'),
          Storage.get('user'),
        ]);
        setShowOnboarding(!onboardingCompleted);
        setIsPanelPinned(!!panelPinned);
        if (storedUser) {
          setUser(storedUser);
          addLog(`Đã đăng nhập: ${storedUser.display_name || storedUser.email}`, 'info');
        }
      } catch (err) {
        console.error('Error loading initial state:', err);
      }
    };
    loadInitialState();
  }, []);

  // Progress Messages Listener
  useEffect(() => {
    const handleProgressMessage = (message, sender, sendResponse) => {
      if (message.action === 'PROCESSING_PROGRESS') {
        setRealtimeProgress({
          current: message.current,
          total: message.total,
          message: message.message,
        });
        addLog(`Tiến độ: ${message.message} (${message.current}/${message.total})`, 'info');
        sendResponse({ ok: true });
        return true;
      }
    };

    chrome.runtime.onMessage.addListener(handleProgressMessage);
    return () => chrome.runtime.onMessage.removeListener(handleProgressMessage);
  }, [addLog]);

  // Processing Complete Listener
  useEffect(() => {
    const handleProcessingCompleteMessage = (message, sender, sendResponse) => {
      if (message.action === 'PROCESSING_COMPLETE') {
        setIsBackgroundProcessing(false);
        clearNotification();
        setRealtimeProgress({ current: 0, total: 0, message: '' });

        if (message.ok) {
          addLog(`Hoàn thành xử lý: ${message.processed}/${message.total} ảnh`, 'success');
          showNotification(
            `✅ Đã dịch ${message.processed}/${message.total} ảnh thành công`,
            'success'
          );

          // 🚀 Cập nhật lại số dư Credit ngay sau khi hoàn thành
          fetchUserProfile();

          if (message.singleImageResult && message.singleImageResult.dataUrl) {
            // Trường hợp ảnh đơn
            setImages((imgs) =>
              imgs.map((img) =>
                img.src === message.singleImageResult.originalSrc
                  ? { ...img, status: 'done', thumb: message.singleImageResult.dataUrl, src: message.singleImageResult.dataUrl }
                  : img
              )
            );
          } else {
            // Trường hợp toàn trang
            setImages((imgs) =>
              imgs.map((img) =>
                img.status === 'queued' || img.status === 'processing'
                  ? { ...img, status: 'done' }
                  : img
              )
            );
          }
        } else {
          const errorMessage = message.error || 'Lỗi không xác định trong quá trình xử lý.';
          addLog(`Lỗi xử lý: ${errorMessage}`, 'error');

          // 🚀 Kiểm tra lỗi 402 (Hết tiền)
          if (errorMessage.includes("402")) {
             showNotification("❌ Bạn không đủ Credit để thực hiện thao tác này. Vui lòng nạp thêm.", "error", 5000);
          } else {
             showNotification(`❌ ${errorMessage}`, 'error');
          }
          
          setImages((imgs) =>
            imgs.map((img) =>
              img.status === 'queued' || img.status === 'processing'
                ? { ...img, status: 'error' }
                : img
            )
          );
        }
      }
    };

    chrome.runtime.onMessage.addListener(handleProcessingCompleteMessage);
    return () => chrome.runtime.onMessage.removeListener(handleProcessingCompleteMessage);
  }, [addLog, showNotification, setImages, clearNotification, fetchUserProfile]);

  // Auto-expand logs
  useEffect(() => {
    if (isBackgroundProcessing && !logsExpanded) {
      setLogsExpanded(true);
    }
  }, [isBackgroundProcessing, logsExpanded]);

  // Handlers
  const handleClose = useCallback(() => {
    const container = document.getElementById('codenova-side-panel-container');
    if (container) {
      container.classList.add('panel-closing');
      setTimeout(() => {
        container.remove();
        window.__CODENOVA_INITIALIZED__ = false;
        window.__CODENOVA_PANEL_INITIALIZED__ = false;
      }, 300);
    }
  }, []);

  const handlePin = useCallback(async () => {
    const newPinnedState = !isPanelPinned;
    setIsPanelPinned(newPinnedState);
    try {
      await Storage.set('panelPinned', newPinnedState);
      showNotification(
        newPinnedState ? '📌 Panel đã được ghim' : '📍 Panel đã gỡ ghim',
        'info',
        2000
      );
    } catch (err) {
      console.error('Error saving pin state:', err);
    }
  }, [isPanelPinned, showNotification]);

  const handleTranslatePage = useCallback(
    async (options) => {
      try {
        showNotification('🚀 Đang bắt đầu xử lý toàn bộ trang...', 'info');
        addLog('Bắt đầu dịch toàn bộ ảnh trên trang', 'info');
        
        if (!images || images.length === 0) {
          throw new Error('Không có ảnh nào để xử lý. Vui lòng làm mới danh sách.');
        }
        
        addLog(`Đang xử lý ${images.length} ảnh...`, 'info');
        setImages((imgs) => imgs.map((img) => ({ ...img, status: 'queued' })));
        newAbortController();
        
        setIsBackgroundProcessing(true);
        const response = await processImages([], 'http://localhost:7000', abortController.signal, {
          source_language: options.sourceLang,
          target_language: options.targetLang,
        });
        
        if (response.ok && response.status === 'started') {
          addLog('Tác vụ xử lý trang đã được khởi tạo trong background.', 'info');
        } else {
          throw new Error(response?.error || 'Không thể khởi tạo tác vụ xử lý trang.');
        }
      } catch (err) {
        const message = ErrorHandler.getUserMessage(err);
        addLog(`Lỗi: ${message}`, 'error');
        showNotification(`❌ ${message}`, 'error');
        setImages((imgs) =>
          imgs.map((img) => ({ ...img, status: img.status === 'queued' ? 'error' : img.status }))
        );
        setIsBackgroundProcessing(false);
      }
    },
    [images, setImages, showNotification, addLog, processImages, newAbortController, abortController.signal, setIsBackgroundProcessing]
  );

  const handleTranslateSelected = useCallback(
    async (options) => {
      try {
        showNotification('🚀 Đang bắt đầu xử lý...', 'info');
        addLog('Bắt đầu dịch trang hiện tại', 'info');
        
        if (!images || images.length === 0) {
          throw new Error('Không có ảnh nào để xử lý. Vui lòng làm mới danh sách.');
        }
        
        const imagesToProcess = images.filter(img => selectedImageIds.has(img.id));
        if (imagesToProcess.length === 0) {
          showNotification('⚠️ Vui lòng chọn ít nhất một ảnh để dịch.', 'info');
          return;
        }

        addLog(`Đang xử lý ${imagesToProcess.length} ảnh đã chọn...`, 'info');
        setImages((imgs) => imgs.map((img) => selectedImageIds.has(img.id) ? { ...img, status: 'queued' } : img));
        newAbortController();
        
        setIsBackgroundProcessing(true);
        const response = await processImages(imagesToProcess, 'http://localhost:7000', abortController.signal, {
          source_language: options.sourceLang,
          target_language: options.targetLang,
        });
        
        if (response.ok && response.status === 'started') {
          addLog('Tác vụ xử lý trang đã được khởi tạo trong background.', 'info');
        } else {
          throw new Error(response?.error || 'Không thể khởi tạo tác vụ xử lý trang.');
        }
      } catch (err) {
        const message = ErrorHandler.getUserMessage(err);
        addLog(`Lỗi: ${message}`, 'error');
        showNotification(`❌ ${message}`, 'error');
        setImages((imgs) =>
          imgs.map((img) => ({
            ...img,
            status: img.status === 'queued' ? 'error' : img.status,
          }))
        );
        setIsBackgroundProcessing(false);
      }
    },
    [images, selectedImageIds, setImages, showNotification, addLog, processImages, newAbortController, abortController.signal, setIsBackgroundProcessing]
  );

  const handleTranslateSingleImage = useCallback(
    async (imageId) => {
      const imageToTranslate = images.find((img) => img.id === imageId);
      if (!imageToTranslate || isBackgroundProcessing) return;

      const currentSourceLang = document.querySelector('.codenova-toolbar .codenova-select:first-of-type')?.value || 'ch';
      const currentTargetLang = document.querySelector('.codenova-toolbar .codenova-select:last-of-type')?.value || 'vi';

      newAbortController();

      try {
        addLog(`Bắt đầu dịch ảnh: ${imageToTranslate.name}`, 'info');
        setImages((imgs) =>
          imgs.map((img) =>
            img.id === imageId ? { ...img, status: 'processing' } : img
          )
        );

        setIsBackgroundProcessing(true);
        const response = await processSingleImage(
          imageToTranslate,
          'http://localhost:7000',
          abortController.signal,
          currentSourceLang,
          currentTargetLang
        );

        if (response.ok && response.status === 'started') {
          addLog(`Tác vụ dịch ảnh ${imageToTranslate.name} đã được khởi tạo trong background.`, 'info');
          showNotification(`🚀 Đang dịch ảnh ${imageToTranslate.name}...`, 'info');
        } else {
          throw new Error(response.error || 'Không thể khởi tạo tác vụ dịch ảnh đơn.');
        }
      } catch (err) {
        const message = ErrorHandler.getUserMessage(err);
        addLog(`Lỗi dịch ảnh: ${message}`, 'error');
        showNotification(`❌ ${message}`, 'error');
        setImages((imgs) =>
          imgs.map((img) =>
            img.id === imageId ? { ...img, status: 'error' } : img
          )
        );
        setIsBackgroundProcessing(false);
      }
    },
    [images, isBackgroundProcessing, setImages, addLog, processSingleImage, newAbortController, abortController.signal, showNotification]
  );

  const handleAbortProcessing = useCallback(() => {
    if (isBackgroundProcessing) {
      abort();
      chrome.runtime.sendMessage({ action: 'CANCEL_PROCESSING' }, (response) => {
        if (chrome.runtime.lastError) {
          console.error('Failed to send cancel signal', chrome.runtime.lastError);
        } else {
          console.log('Cancel signal sent to background script.', response);
        }
      });

      addLog('Đã yêu cầu dừng xử lý.', 'info');
      showNotification('🛑 Đã dừng xử lý', 'info');
      setIsBackgroundProcessing(false);
      setImages((imgs) =>
        imgs.map((img) => (img.status === 'queued' || img.status === 'processing' ? { ...img, status: 'pending' } : img))
      );
    }
  }, [isBackgroundProcessing, abort, addLog, showNotification, setImages]);

  const handleEditImage = useCallback(
    (imageId) => {
      setSelectedImageId(imageId);
      addLog(`Mở chỉnh sửa ảnh: ${images.find((img) => img.id === imageId)?.name}`, 'info');
    },
    [images, addLog]
  );

  const handleClearImage = useCallback(
    (imageId) => {
      const imageToDelete = images.find((img) => img.id === imageId);
      if (imageToDelete) {
        setImages((imgs) => imgs.filter((img) => img.id !== imageId));
        removeFromQueue(imageId);
        addLog(`Đã xóa ảnh: ${imageToDelete.name}`, 'info');
        showNotification('🗑️ Đã xóa ảnh', 'info', 2000);
      }
    },
    [images, setImages, removeFromQueue, addLog, showNotification]
  );

  const handleRefreshImages = useCallback(async () => {
    try {
      showNotification('🔄 Đang làm mới danh sách...', 'info', 1500);
      await fetchImages();
      addLog('Làm mới danh sách ảnh thành công', 'success');
    } catch (err) {
      addLog(`Lỗi khi làm mới: ${err.message}`, 'error');
    }
  }, [fetchImages, showNotification, addLog]);

  useKeyboard(
    {
      escape: () => selectedImageId ? setSelectedImageId(null) : handleClose(),
      'ctrl+p': (e) => {
        e.preventDefault();
        handlePin();
      },
      'ctrl+l': () => setLogsExpanded(!logsExpanded),
      'ctrl+a': (e) => {
        e.preventDefault();
        const allIds = new Set(images.map(img => img.id));
        setSelectedImageIds(allIds);
        addLog(`Đã chọn tất cả ${allIds.size} ảnh.`, 'info');
      }
    },
    [selectedImageId, logsExpanded]
  );

  return (
    <>
      {showOnboarding && (
        <Onboarding onComplete={() => setShowOnboarding(false)} />
      )}

      {!cssLoaded && (
        <div style={{
          position: 'absolute',
          inset: 0,
          background: 'rgba(255, 255, 255, 0.95)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 9999,
        }}>
          <div style={{
            textAlign: 'center',
            padding: '24px',
          }}>
            <div style={{
              width: '48px',
              height: '48px',
              border: '4px solid #e5e7eb',
              borderTop: '4px solid #3b82f6',
              borderRadius: '50%',
              margin: '0 auto 16px',
              animation: 'spin 1s linear infinite',
            }} />
            <p style={{
              margin: 0,
              color: '#64748b',
              fontSize: '14px',
              fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
            }}>
              Loading CODENOVA...
            </p>
          </div>
        </div>
      )}

      <div 
        className="codenova-panel"
        style={{
          position: 'fixed',
          right: 0,
          top: 0,
          width: '384px',
          height: '100vh',
          background: '#ffffff',
          boxShadow: '-4px 0 24px rgba(0, 0, 0, 0.15)',
          display: 'flex',
          flexDirection: 'column',
          fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
          fontSize: '14px',
          color: '#1e293b',
          zIndex: 2147483647,
          opacity: cssLoaded ? 1 : 0,
          transition: 'opacity 0.3s ease',
        }}
      >
        {/* 🚀 SỬA: Truyền userCredit vào Header */}
        <Header
          onPin={handlePin}
          onClose={handleClose}
          isPinned={isPanelPinned}
          credit={userCredit} 
        />
        
        <ActionToolbar
          onTranslatePage={handleTranslatePage}
          onTranslateSelected={handleTranslateSelected}
          selectedCount={selectedImageIds.size}
          isLoading={isBackgroundProcessing}
          onAbort={handleAbortProcessing}
        />
        <main className="codenova-main" style={{
          flex: 1,
          overflowY: 'auto',
          background: '#f8fafc',
          padding: '12px',
        }}>
          {selectedImage ? (
            <EditorView
              image={selectedImage}
              onBack={() => setSelectedImageId(null)}
              onSave={() => {}}
            />
          ) : (
            <PageListView
              images={images}
              isLoading={loading}
              onEditImage={handleEditImage}
              onDeleteImage={handleClearImage}
              onTranslateImage={handleTranslateSingleImage}
              selectedIds={selectedImageIds}
              onSelectionChange={(id, isSelected) => {
                setSelectedImageIds(prev => {
                  const newSet = new Set(prev);
                  isSelected ? newSet.add(id) : newSet.delete(id);
                  return newSet;
                });
              }}
            />
          )}
        </main>
        <StatusLogs
          isExpanded={logsExpanded}
          onToggle={() => setLogsExpanded(!logsExpanded)}
          logs={processLog}
          progress={realtimeProgress}
        />
        <Footer stats={processingStats} onRefresh={handleRefreshImages} user={user} />

        {error && !loading && (
          <div className="codenova-error-overlay">
            <div className="codenova-error-box">
              <div className="codenova-error-icon">!</div>
              <div className="codenova-error-content">
                <p className="codenova-error-title">Có lỗi xảy ra</p>
                <p className="codenova-error-message">{error}</p>
              </div>
              <button onClick={handleRefreshImages} className="codenova-error-btn">
                Thử lại
              </button>
            </div>
          </div>
        )}
      </div>

      {notification && (
        <Notification {...notification} onClose={clearNotification} />
      )}
    </>
  );
}

export default SidePanel;