# 📁 CODENOVA Extension - Project Structure

## 🗂️ Cấu trúc thư mục

```
codenova-extension/
├── public/
│   ├── manifest.json          # ← Updated manifest
│   ├── popup.html             # ← Popup UI
│   ├── side-panel-init.js     # ← Side panel initialization
│   └── icons/
│       ├── icon16.png
│       ├── icon48.png
│       └── icon128.png
│
├── src/
│   ├── background/
│   │   └── background.js      # ← Keep as is, updated with integration
│   │
│   ├── content/
│   │   └── content.js         # ← Keep as is, updated with integration
│   │
│   ├── popup/
│   │   ├── popup.js           # ← Main popup logic
│   │   └── popup.html         # ← Popup template
│   │
│   ├── panel/
│   │   ├── SidePanel.jsx      # ← Main side panel component
│   │   ├── index.jsx          # ← Entry point for panel
│   │   └── styles.css         # ← Panel styles
│   │
│   ├── components/
│   │   ├── Header.jsx         # ← Header component
│   │   ├── ActionToolbar.jsx  # ← Toolbar component
│   │   ├── PageListView.jsx   # ← List view component
│   │   ├── PageListItem.jsx   # ← List item component
│   │   ├── EditorView.jsx     # ← Editor component
│   │   ├── StatusLogs.jsx     # ← Status logs
│   │   ├── Footer.jsx         # ← Footer
│   │   ├── Notification.jsx   # ← Notification
│   │   ├── Onboarding.jsx     # ← Onboarding
│   │   ├── EmptyState.jsx     # ← Empty state
│   │   ├── StatusIndicator.jsx
│   │   └── tabs/
│   │       ├── TextFontTab.jsx
│   │       └── AdvancedTab.jsx
│   │
│   ├── hooks/
│   │   ├── useImages.js       # ← Fetch images hook
│   │   ├── useAnimation.js    # ← Animation hook
│   │   ├── useNotification.js # ← Notification hook
│   │   └── useImageProcessing.js # ← Processing hook
│   │
│   ├── constants/
│   │   └── colors.js          # ← Color palette & animations
│   │
│   ├── utils/
│   │   ├── errorHandler.js    # ← Error handling
│   │   ├── imageUtils.js      # ← Image utilities
│   │   └── storage.js         # ← Chrome storage wrapper
│   │
│   └── index.jsx              # ← Main entry point
│
├── build/                     # ← Built files (after build)
├── node_modules/
├── package.json
├── webpack.config.js          # ← Webpack config
├── babel.config.js
└── README.md
```

## 🚀 Quick Start

### 1. **Cài đặt dependencies**

```bash
npm install
```

### 2. **Cài đặt packages cần thiết**

```bash
npm install react react-dom lucide-react
npm install --save-dev webpack webpack-cli babel-loader @babel/core @babel/preset-react @babel/preset-env
npm install --save-dev css-loader style-loader
```

### 3. **Build extension**

```bash
npm run build
```

### 4. **Load extension vào Chrome**

1. Mở Chrome
2. Truy cập `chrome://extensions/`
3. Bật "Developer mode"
4. Click "Load unpacked"
5. Chọn folder `build/` hoặc `public/`

## 📋 Các tệp quan trọng

### **popup.html**
- Giao diện popup khi click extension icon
- Buttons: "Mở Panel", "Dịch Trang", "Dịch Toàn bộ"

### **popup.js**
- Logic xử lý các button trong popup
- Tương tác với background script
- Show/hide notifications

### **side-panel-init.js**
- Khởi tạo React app cho side panel
- Load React từ CDN
- Mount SidePanel component

### **SidePanel.jsx**
- Component chính của side panel
- Quản lý state chung
- Điều phối các sub-components

### **components/**
- Các component UI riêng biệt
- Dễ tái sử dụng và mở rộng
- Mỗi component có logic riêng

### **hooks/**
- Custom React hooks
- Tái sử dụng logic
- Quản lý side effects

### **constants/colors.js**
- Định nghĩa toàn bộ color palette
- CSS animations
- Dễ thay đổi theme

### **utils/**
- Utility functions
- Chrome storage wrapper
- Error handling

## 🔄 Data Flow

```
popup.html
    ↓
popup.js (sends message)
    ↓
background.js (processes request)
    ↓
content.js (gets/replaces images)
    ↓
SidePanel.jsx (displays results)
    ├── PageListView (list images)
    ├── EditorView (edit single image)
    └── Notification (show feedback)
```

## 🎨 Component Hierarchy

```
SidePanel
├── Header
├── ActionToolbar
├── PageListView/EditorView
│   ├── PageListItem
│   ├── StatusIndicator
│   ├── TextFontTab
│   └── AdvancedTab
├── StatusLogs
├── Footer
├── Notification
└── Onboarding
```

## 🔧 Extensibility

### Thêm component mới

1. Tạo file mới trong `components/`
2. Export component
3. Import trong SidePanel.jsx
4. Add props nếu cần

```jsx
// components/NewFeature.jsx
export function NewFeature({ data, onAction }) {
  return <div>{/* Your component */}</div>;
}
```

### Thêm hook mới

1. Tạo file trong `hooks/`
2. Export hook function
3. Sử dụng trong components

```js
// hooks/useNewFeature.js
export function useNewFeature() {
  const [state, setState] = useState(null);
  // ... logic
  return { state, setState };
}
```

### Thêm animation mới

1. Thêm animation CSS trong `constants/colors.js`
2. Reference trong component

```js
// constants/colors.js
@keyframes myAnimation {
  from { /* ... */ }
  to { /* ... */ }
}
```

## 📦 package.json Template

```json
{
  "name": "codenova-extension",
  "version": "1.1.0",
  "description": "Comic Image Translator with AI",
  "scripts": {
    "dev": "webpack --mode development --watch",
    "build": "webpack --mode production",
    "watch": "webpack --mode development --watch"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "lucide-react": "^0.263.1"
  },
  "devDependencies": {
    "@babel/core": "^7.22.0",
    "@babel/preset-env": "^7.22.0",
    "@babel/preset-react": "^7.22.0",
    "babel-loader": "^9.1.2",
    "webpack": "^5.88.0",
    "webpack-cli": "^5.1.4",
    "css-loader": "^6.8.1",
    "style-loader": "^3.3.3"
  }
}
```

## 🔌 Integration Checklist

- ✅ popup.html + popup.js
- ✅ side-panel-init.js
- ✅ SidePanel.jsx (main component)
- ✅ All sub-components
- ✅ All hooks
- ✅ constants/colors.js
- ✅ utils/ folder
- ✅ manifest.json (updated)
- ✅ background.js (integration)
- ✅ content.js (integration)

## 🚨 Common Issues

### Issue: Components not loading
**Solution**: Check if React is loaded from CDN in side-panel-init.js

### Issue: Styles not applied
**Solution**: Ensure animationsCSS is injected in SidePanel.jsx

### Issue: Images not fetching
**Solution**: Check content.js GET_IMAGE_LIST message handler

### Issue: API calls failing
**Solution**: Ensure background.js PROCESS_PAGE_IMAGES is working

## 📝 Notes

- Tất cả animations được định nghĩa trong `constants/colors.js`
- Color palette đã được thiết kế đầy đủ
- Components đã được cấu trúc để dễ mở rộng
- Hooks giúp tái sử dụng logic dễ dàng
- Storage wrapper cho Chrome storage

## 🤝 Contributing

Khi thêm feature mới:
1. Tạo component/hook riêng
2. Đặt tên rõ ràng
3. Thêm comments
4. Update structure doc này