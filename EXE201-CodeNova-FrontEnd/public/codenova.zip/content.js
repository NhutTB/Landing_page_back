(function () {
  'use strict';

  const MIN_ABSOLUTE_IMAGE_SIZE = 20;
  const DEFAULT_MIN_SIZE = 200;

  // ========== Logging Helper ==========
  function log(message, data = null) {
    const timestamp = new Date().toISOString().split('T')[1].slice(0, -1);
    console.log(`[${timestamp}] [content] ${message}`);
    if (data) console.log(data);
  }

  function logError(message, error) {
    const timestamp = new Date().toISOString().split('T')[1].slice(0, -1);
    console.error(`[${timestamp}] [content] ❌ ${message}`);
    console.error(error);
  }

  // ========== Helpers ==========
  function isHttp(u) {
    return /^https?:\/\//i.test(u);
  }

  function isGif(u) {
    try {
      return new URL(u, location.href).pathname.toLowerCase().endsWith('.gif');
    } catch {
      return false;
    }
  }

  // ========== Site-specific Logic: MangaDex ==========
  function isMangadexPage() {
    try {
      const u = new URL(location.href);
      return u.hostname.includes('mangadex.org') && /^\/chapter\/[0-9a-f-]+/.test(u.pathname);
    } catch {
      return false;
    }
  }

  function getMangadexChapterId() {
    const match = location.pathname.match(/^\/chapter\/([0-9a-f-]+)/);
    return match ? match[1] : null;
  }

  async function fetchMangadexApiImages() {
    const chapterId = getMangadexChapterId();
    if (!chapterId) return [];

    const apiUrl = `https://api.mangadex.org/at-home/server/${chapterId}`;
    log(`MangaDex detected. Fetching API: ${apiUrl}`);

    try {
      const resp = await fetch(apiUrl, { method: 'GET' });
      if (!resp.ok) {
        throw new Error(`MangaDex API returned status ${resp.status}`);
      }
      const json = await resp.json();

      const baseUrl = json?.baseUrl;
      const chapter = json?.chapter;
      const hash = chapter?.hash;
      const data = Array.isArray(chapter?.data) ? chapter.data : [];

      if (!baseUrl || !hash || data.length === 0) {
        logError('MangaDex API response is invalid', json);
        return [];
      }

      const imageList = data.map((filename, i) => ({
        src: `${baseUrl}/data/${hash}/${filename}`,
        type: 'mangadex-api',
        index: i + 1,
        filename: filename,
      }));

      log(`✅ MangaDex API successful. Found ${imageList.length} images`);
      return imageList;
    } catch (err) {
      logError('Failed to fetch from MangaDex API', err);
      return [];
    }
  }

  // ========== Generic Site Logic ==========
  async function triggerLazyLoad() {
    log('🔄 Starting lazy load trigger...');
    const originalScrollY = window.scrollY;
    const scrollStep = window.innerHeight * 0.9; // Cuộn 90% viewport mỗi lần
    const scrollDelay = 250; // Giảm thời gian chờ giữa các lần cuộn
    const stabilityChecks = 3; // Số lần kiểm tra liên tiếp không có ảnh mới
    const stabilityDelay = 350; // Thời gian chờ giữa các lần kiểm tra ổn định

    let lastImgCount = 0;
    let stableCount = 0;
    let currentScroll = 0;

    // Cuộn xuống cuối trang
    while (stableCount < stabilityChecks) {
      const maxScroll = Math.max(
        document.documentElement.scrollHeight,
        document.body.scrollHeight,
        document.documentElement.clientHeight
      );

      window.scrollTo(0, currentScroll);
      await new Promise(r => setTimeout(r, scrollDelay));

      const currentImgCount = document.querySelectorAll('img[src]').length;
      log(`   Scrolled to ${Math.round(currentScroll)}px, found ${currentImgCount} images with src.`);

      if (currentImgCount > lastImgCount) {
        stableCount = 0; // Reset bộ đếm nếu có ảnh mới
        lastImgCount = currentImgCount;
      } else {
        stableCount++; // Tăng bộ đếm nếu không có ảnh mới
      }

      if (currentScroll >= maxScroll - window.innerHeight) {
        // Đã gần hoặc ở cuối trang, bắt đầu kiểm tra ổn định
        log(`   Reached bottom, checking for stability (${stableCount}/${stabilityChecks})...`);
        await new Promise(r => setTimeout(r, stabilityDelay));
      } else {
        currentScroll += scrollStep;
      }
    }

    // Cuộn thêm một lần cuối cùng để chắc chắn
    const finalMaxScroll = Math.max(document.documentElement.scrollHeight, document.body.scrollHeight);
    window.scrollTo(0, finalMaxScroll);
    await new Promise(r => setTimeout(r, 400));

    // Cuộn về vị trí ban đầu
    window.scrollTo(0, originalScrollY);
    await new Promise(r => setTimeout(r, 100));

    const finalImgCount = document.querySelectorAll('img').length;
    log(`✅ Lazy load trigger complete. Total images found: ${finalImgCount}`);
  }

  async function collectGenericImages(minSize = DEFAULT_MIN_SIZE, waitForLazyLoad = true) {
    log(`Scanning DOM for images (minSize: ${minSize}px)...`);

    // 🔥 THÊM: Trigger lazy load nếu cần
    if (waitForLazyLoad) {
      await triggerLazyLoad();
    }

    const results = new Set();
    const allImages = document.querySelectorAll('img');

    log(`Found ${allImages.length} img elements in DOM`);


    allImages.forEach((img) => {
      const width = img.naturalWidth || img.width;
      const height = img.naturalHeight || img.height;

      if (width < minSize || height < minSize) {
        return;
      }

      const potentialUrls = [
        img.getAttribute('data-original'),
        img.getAttribute('data-cdn'),
        img.getAttribute('data-src'),
        img.currentSrc,
        img.src,
        img.srcset ? img.srcset.split(',').pop().trim().split(' ')[0] : null,
      ].filter(Boolean);

      for (const url of potentialUrls) {
        if (url.startsWith('data:') || url.startsWith('blob:')) continue;
        try {
          const absoluteUrl = new URL(url, location.href).toString();
          if (isHttp(absoluteUrl) && !isGif(absoluteUrl)) {
            results.add(absoluteUrl);
            break;
          }
        } catch (e) {
          // Ignore invalid URLs
        }
      }
    });

    log(`✅ Collected ${results.size} unique image URLs`);
    return Array.from(results);
  }

  // ========== Main Orchestrator ==========
  async function gatherImages(minSize = DEFAULT_MIN_SIZE) {
    log('='.repeat(60));
    log(`Starting image gathering (minSize: ${minSize}px)`);
    log(`Current URL: ${location.href}`);

    if (isMangadexPage()) {
      log('Detected MangaDex page');
      const images = await fetchMangadexApiImages();
      log('='.repeat(60));
      return images;
    }

    log('Generic site detected. Scanning DOM...');
    const urls = await collectGenericImages(minSize, true); // 🔥 THÊM await và true
    const images = urls.map((src, i) => ({
      src,
      index: i + 1,
      type: 'generic-dom',
      filename: (src.substring(src.lastIndexOf('/') + 1).split('?')[0] || `image_${i + 1}`)
        .replace(/[/\\?%*:|"<>]/g, '_')
        .slice(0, 200)
        + '.jpg',
    }));

    log('='.repeat(60));
    return images;
  }

  // ========== Site-specific Replacement: MangaDex ==========
  const mangadexReplacementMap = new Map();

  function replaceMangadexImages(processedImages) {
    log('MangaDex detected. Using specific replacement logic.');

    processedImages.forEach(img => {
      const pageNum = getPageNumberFromSrc(img.originalSrc);
      mangadexReplacementMap.set(pageNum, img.newSrc);
    });

    const selectors = [
      'img.img.sp.limit-width.limit-height',
      'div[data-page] img',
      'img[alt*=".png"]',
      'img[src^="blob:"]'
    ];

    let imageElements = [];
    for (const selector of selectors) {
      imageElements = Array.from(document.querySelectorAll(selector));
      if (imageElements.length > 0) {
        log(`✅ Found ${imageElements.length} images using selector: ${selector}`);
        break;
      }
    }

    if (imageElements.length === 0) {
      logError('Could not find MangaDex image containers');
      return 0;
    }

    let replacedCount = 0;
    const descriptor = Object.getOwnPropertyDescriptor(HTMLImageElement.prototype, 'src');

    imageElements.forEach((imgEl, index) => {
      const currentPage = index + 1;
      const newSrc = mangadexReplacementMap.get(currentPage);

      if (!newSrc) return;

      Object.defineProperty(imgEl, 'src', {
        get() { return newSrc; },
        set(value) {
          log(`🛡️ Blocked src change attempt: ${value.substring(0, 40)}...`);
        },
        configurable: true
      });

      descriptor.set.call(imgEl, newSrc);
      if (imgEl.srcset) imgEl.srcset = '';
      imgEl.removeAttribute('data-src');

      replacedCount++;
    });

    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.type === 'attributes' && mutation.attributeName === 'src') {
          const imgEl = mutation.target;
          const currentSrc = imgEl.getAttribute('src');
          const allImages = Array.from(document.querySelectorAll('img.img.sp.limit-width.limit-height'));
          const pageIndex = allImages.indexOf(imgEl);
          const pageNum = pageIndex + 1;
          const correctSrc = mangadexReplacementMap.get(pageNum);

          if (correctSrc && currentSrc !== correctSrc && !currentSrc.startsWith('data:image')) {
            log(`🔄 MangaDex tried to change page ${pageNum} back! Restoring...`);
            imgEl.setAttribute('src', correctSrc);
          }
        }
      });
    });

    imageElements.forEach(imgEl => {
      observer.observe(imgEl, { attributes: true, attributeFilter: ['src'] });
    });

    log(`🛡️ MutationObserver active on ${imageElements.length} images`);
    return replacedCount;
  }

  function getPageNumberFromSrc(src) {
    const filename = src.substring(src.lastIndexOf('/') + 1);
    const match = filename.match(/^(\d+)-/);
    return match ? parseInt(match[1], 10) : -1;
  }

  // ========== 🚀 OPTIMIZED: Parallel Image Replacement ==========
  function replaceImagesOnPage(processedImages) {
    log('='.repeat(60));
    log(`Starting image replacement with ${processedImages.length} processed images`);

    if (isMangadexPage()) {
      const replacedCount = replaceMangadexImages(processedImages);
      log(`✅ Successfully replaced ${replacedCount} images on page (MangaDex)`);
      return replacedCount;
    }

    // 🚀 Build lookup map (O(1) instead of O(n))
    const imageMap = new Map();
    processedImages.forEach(img => {
      imageMap.set(img.originalSrc, img.newSrc);
    });

    const allImages = document.querySelectorAll('img');
    log(`Scanning ${allImages.length} img elements for replacement...`);

    let replacedCount = 0;

    // 🚀 Use requestAnimationFrame batching for smoother UI
    const BATCH_SIZE = 20;
    const imagesToProcess = Array.from(allImages);

    function processBatch(startIndex) {
      const endIndex = Math.min(startIndex + BATCH_SIZE, imagesToProcess.length);

      for (let i = startIndex; i < endIndex; i++) {
        const imgEl = imagesToProcess[i];
        const sources = [
          imgEl.src,
          imgEl.currentSrc,
          imgEl.getAttribute('data-original'),
          imgEl.getAttribute('data-cdn'),
          imgEl.getAttribute('data-src')
        ].filter(Boolean);

        for (const src of sources) {
          try {
            const absoluteUrl = new URL(src, location.href).toString();
            if (imageMap.has(absoluteUrl)) {
              const newSrc = imageMap.get(absoluteUrl);

              // 🚀 Single assignment instead of multiple
              imgEl.src = newSrc;
              imgEl.srcset = '';

              // 🚀 Only update data attributes if they exist
              if (imgEl.hasAttribute('data-original')) imgEl.dataset.original = newSrc;
              if (imgEl.hasAttribute('data-cdn')) imgEl.dataset.cdn = newSrc;
              if (imgEl.hasAttribute('data-src')) imgEl.dataset.src = newSrc;

              replacedCount++;
              break;
            }
          } catch (e) {
            // Ignore parsing errors
          }
        }
      }

      if (endIndex < imagesToProcess.length) {
        requestAnimationFrame(() => processBatch(endIndex));
      } else {
        log(`✅ Successfully replaced ${replacedCount} images on page`);
        log('='.repeat(60));
      }
    }

    processBatch(0);
    return replacedCount;
  }

  // ========== 🚀 OPTIMIZED: Faster Image Fetching ==========
  async function fetchImagesAsBlobs(imageList, concurrency = 10) {
    log('='.repeat(60));
    log(`🚀 Starting batch fetch for ${imageList.length} images (concurrency=${concurrency})`);

    async function fetchSingleImage(url) {
      // Try canvas first (fastest)
      try {
        const canvasResult = await tryCanvasMethod(url);
        if (canvasResult.ok) {
          return canvasResult;
        }
      } catch (err) {
        // Fallback to proxy
      }

      // Fallback to background proxy
      try {
        const proxyResponse = await chrome.runtime.sendMessage({
          action: 'FETCH_IMAGE_PROXY',
          url,
          referer: location.href,
        });

        if (!proxyResponse?.ok || !proxyResponse.arrayBuffer) {
          throw new Error(proxyResponse?.error || 'Proxy failed');
        }

        if (proxyResponse.size < 100) {
          throw new Error(`Response too small: ${proxyResponse.size} bytes`);
        }

        return {
          ok: true,
          arrayBuffer: proxyResponse.arrayBuffer,
          type: proxyResponse.contentType || 'image/jpeg',
          size: proxyResponse.size,
          via: 'proxy'
        };
      } catch (err) {
        return {
          ok: false,
          error: `Fetch failed: ${err.message}`,
          url: url
        };
      }
    }

    function tryCanvasMethod(url) {
      return new Promise((resolve, reject) => {
        const img = new Image();
        img.crossOrigin = 'anonymous';

        const timeout = setTimeout(() => {
          cleanup();
          reject(new Error('Canvas timeout'));
        }, 10000); // Reduced from 15s to 10s

        const cleanup = () => {
          clearTimeout(timeout);
          img.onload = null;
          img.onerror = null;
        };

        img.onload = () => {
          cleanup();
          try {
            const canvas = document.createElement('canvas');
            canvas.width = img.naturalWidth || img.width || 800;
            canvas.height = img.naturalHeight || img.height || 600;
            const ctx = canvas.getContext('2d', { alpha: false }); // 🚀 Faster without alpha
            ctx.drawImage(img, 0, 0);

            canvas.toBlob(async (blob) => {
              if (!blob) {
                return reject(new Error('toBlob failed'));
              }
              const arrayBuffer = await blob.arrayBuffer();
              resolve({
                ok: true,
                arrayBuffer,
                type: blob.type || 'image/jpeg',
                size: arrayBuffer.byteLength,
                via: 'canvas'
              });
            }, 'image/jpeg', 0.92); // 🚀 Slightly lower quality for speed
          } catch (e) {
            reject(new Error(`Canvas error: ${e.message}`));
          }
        };

        img.onerror = () => {
          cleanup();
          reject(new Error('Image load error'));
        };

        img.src = url;
      });
    }

    // ========== Worker Pool ==========
    let index = 0;
    const results = new Array(imageList.length);

    async function worker(workerId) {
      while (true) {
        const i = index++;
        if (i >= imageList.length) break;

        const img = imageList[i];
        try {
          const fetchResult = await fetchSingleImage(img.src);

          if (fetchResult.ok) {
            // 🚀 CRITICAL: Transfer ArrayBuffer as-is (no conversion)
            results[i] = {
              ok: true,
              originalSrc: img.src,
              filename: img.filename,
              arrayBuffer: Array.from(new Uint8Array(fetchResult.arrayBuffer)), // Convert to plain array for message passing
              type: fetchResult.type,
              size: fetchResult.size,
              via: fetchResult.via
            };
          } else {
            throw new Error(fetchResult.error || 'Unknown error');
          }
        } catch (err) {
          results[i] = {
            ok: false,
            originalSrc: img.src,
            filename: img.filename,
            error: err.message || String(err)
          };
        }
      }
    }

    // Start workers
    const workers = [];
    const numWorkers = Math.min(concurrency, imageList.length);
    for (let w = 0; w < numWorkers; w++) {
      workers.push(worker(w + 1));
    }

    await Promise.all(workers);

    const successCount = results.filter(r => r?.ok).length;
    log(`✅ Batch fetch complete: ${successCount}/${imageList.length} successful`);
    log('='.repeat(60));

    return results;
  }

  // ========== Message Handler ==========
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    log(`Received message: ${msg?.action || 'unknown'}`);

    (async () => {
      try {
        if (msg?.action === 'GET_IMAGE_LIST') {
          await new Promise(resolve => {
            if (document.readyState === 'complete') {
              return resolve();
            }
            const onReady = () => {
              if (document.readyState === 'complete') {
                document.removeEventListener('readystatechange', onReady);
                resolve();
              }
            };
            document.addEventListener('readystatechange', onReady);
          });

          const min = Number(msg.minSize || DEFAULT_MIN_SIZE);
          const list = await gatherImages(min);
          sendResponse({ ok: true, images: list });
        }
        else if (msg?.action === 'REPLACE_IMAGES') {
          if (!Array.isArray(msg.images)) {
            throw new Error('Invalid images array');
          }
          const replacedCount = replaceImagesOnPage(msg.images);
          sendResponse({ ok: true, replaced: replacedCount });
        }
        else if (msg?.action === 'FETCH_IMAGES_AS_BLOBS') {
          if (!Array.isArray(msg.images)) {
            throw new Error('Invalid images array');
          }
          const blobData = await fetchImagesAsBlobs(msg.images);
          sendResponse({ ok: true, blobs: blobData });
        }
        else if (msg?.action === 'PROCESSING_PROGRESS') {
          // Let the panel handle this, content script does nothing.
          sendResponse({ ok: true });
        }
        else if (msg?.action === 'PROCESSING_COMPLETE') {
          // Let the panel handle this, content script does nothing.
          sendResponse({ ok: true });
        }
        else {
          logError('Unknown action', new Error(`Action: ${msg?.action}`));
          sendResponse({ ok: false, error: 'unknown-action' });
        }
      } catch (e) {
        logError(`Error handling ${msg?.action}`, e);
        sendResponse({ ok: false, error: e.message || String(e) });
      }
    })();

    return true;
  });

  window.addEventListener('CODENOVA_REPLACE_IMAGES', (event) => {
    if (event.detail?.images) {
      try {
        replaceImagesOnPage(event.detail.images);
      } catch (e) {
        logError('Page-level replacement error', e);
      }
    }
  });

  log('🚀 Content script initialized');
})();