(function() {
  console.log('[CODENOVA] Starting injection...');

  // Prevent duplicate injection
  if (window.__CODENOVA_INITIALIZED__) {
    console.log('[CODENOVA] Already initialized, skipping.');
    return;
  }
  window.__CODENOVA_INITIALIZED__ = true;

  // Expose a safe global flag
  window.hasChromeAPI = (typeof chrome !== 'undefined') &&
                        (typeof chrome.runtime !== 'undefined') &&
                        (typeof chrome.runtime.sendMessage === 'function');

  // ✅ Inject CSS first - ĐÂY LÀ PHẦN QUAN TRỌNG
  const cssLink = document.createElement('link');
  cssLink.rel = 'stylesheet';
  cssLink.type = 'text/css';
  cssLink.href = chrome.runtime.getURL('build/side-panel.css');
  cssLink.id = 'codenova-styles';
  document.head.appendChild(cssLink);
  console.log('[CODENOVA] CSS injected:', cssLink.href);

  // Create container
  const container = document.createElement('div');
  container.id = 'codenova-side-panel-container';
  container.style.cssText = `
    position: fixed;
    top: 0;
    right: 0;
    width: 384px;
    height: 100vh;
    z-index: 2147483647;
  `;

  // Create React mount point inside the container
  const root = document.createElement('div');
  root.id = 'root';
  container.appendChild(root);
  
  document.body.appendChild(container);

  console.log('[CODENOVA] Container and CSS injected.');
  console.log('[CODENOVA] DOM initialization complete.');
})();