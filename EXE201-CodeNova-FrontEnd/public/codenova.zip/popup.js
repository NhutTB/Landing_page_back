// ====== Popup Script - popup.js ======

const UI = {
  statusBox: document.getElementById('statusBox'),
  errorBox: document.getElementById('errorBox'),
  successBox: document.getElementById('successBox'),
  openPanelBtn: document.getElementById('openPanelBtn'),
  translatePageBtn: document.getElementById('translatePageBtn'),
  translateAllBtn: document.getElementById('translateAllBtn'),
};

// --- Auth UI elements (added) ---
const emailInput = document.getElementById('emailInput');
const passwordInput = document.getElementById('passwordInput');
const loginBtn = document.getElementById('loginBtn');
const logoutBtn = document.getElementById('logoutBtn');
const accountInfo = document.getElementById('accountInfo');
const authForm = document.getElementById('authForm');
const accountName = document.getElementById('accountName');
const authMsg = document.getElementById('authMsg');
const mainContent = document.getElementById('mainContent');

const API_BASE = 'http://localhost:5000/api'; // <-- Chỉnh lại nếu backend của bạn chạy trên port khác



// ====== Helper Functions ======

function showError(message) {
  UI.errorBox.textContent = '❌ ' + message;
  UI.errorBox.classList.add('show');
  setTimeout(() => UI.errorBox.classList.remove('show'), 4000);
}

function showSuccess(message) {
  UI.successBox.textContent = '✓ ' + message;
  UI.successBox.classList.add('show');
  setTimeout(() => UI.successBox.classList.remove('show'), 3000);
}

function setLoading(btn, isLoading) {
  if (isLoading) {
    btn.disabled = true;
    btn.innerHTML = '<span class="loading-spinner"></span> Đang xử lý...';
  } else {
    btn.disabled = false;
  }
}

function updateStatus(message, isActive = true) {
  const indicator = UI.statusBox.querySelector('.status-indicator');
  const text = UI.statusBox.querySelector('p');
  
  text.textContent = message;
  if (isActive) {
    indicator.style.background = '#10B981';
  } else {
    indicator.style.background = '#94A3B8';
  }
}

// --- Auth helpers ---
async function refreshAuthUI() {
  try {
    // Compatibility: use chrome.storage directly
    chrome.storage.local.get(['token','user'], (res) => {
      if (chrome.runtime.lastError) {
        console.error('[popup] Error getting auth state:', chrome.runtime.lastError);
        authMsg.textContent = 'Lỗi tải trạng thái';
        return;
      }
      const token = res?.token;
      const user = res?.user;
      if (token) {
        mainContent.style.display = 'block';
        authForm.style.display = 'none';
        accountInfo.style.display = 'block';
        accountName.textContent = user?.display_name || user?.email || 'Người dùng';
        authMsg.textContent = 'Đã đăng nhập';
      } else {
        mainContent.style.display = 'none';
        authForm.style.display = 'block';
        accountInfo.style.display = 'none';
        accountName.textContent = '';
        authMsg.textContent = 'Chưa đăng nhập';
      }
    });
  } catch (e) {
    console.warn('[popup] refreshAuthUI error', e);
    authMsg.textContent = 'Lỗi giao diện xác thực';
  }
}

loginBtn.addEventListener('click', async () => {
  const email = (emailInput.value || '').trim();
  const password = (passwordInput.value || '').trim();
  if (!email || !password) { authMsg.textContent = 'Nhập email và mật khẩu'; return; }
  loginBtn.disabled = true;
  authMsg.textContent = 'Đang đăng nhập...';

  // // ====== BEGIN: MOCK LOGIN FOR TESTING (NO DATABASE NEEDED) ======
  // // Nếu bạn nhập email là "test@test.com", nó sẽ đăng nhập giả mà không cần backend
  // if (email === 'test@test.com') {
  //   console.log('[popup] MOCK LOGIN: Using test user.');
  //   const mockData = {
  //     token: 'mock_token_for_testing_' + Date.now(),
  //     user: { email: 'test@test.com', display_name: 'Test User' }
  //   };
  //   await chrome.storage.local.set({ token: mockData.token, user: mockData.user });
  //   chrome.runtime.sendMessage({ action: 'TOKEN_UPDATED', token: mockData.token, user: mockData.user });
  //   authMsg.textContent = 'Đăng nhập thử nghiệm thành công';
  //   await refreshAuthUI();
  //   passwordInput.value = '';
  //   loginBtn.disabled = false;
  //   return; // Dừng ở đây, không gọi API thật
  // }
  // // ====== END: MOCK LOGIN FOR TESTING ======


  try {
    const res = await fetch(`${API_BASE}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || data.message || 'Login failed');

    // lưu token + user
    await chrome.storage.local.set({ token: data.token, user: data.user });
    // Notify background
    chrome.runtime.sendMessage({ action: 'TOKEN_UPDATED', token: data.token, user: data.user });
    authMsg.textContent = 'Đăng nhập thành công';
    await refreshAuthUI();
    // optional: clear password field
    passwordInput.value = '';
  } catch (err) {
    console.error('[popup] login error', err);
    authMsg.textContent = 'Lỗi đăng nhập: ' + (err.message || err);
  } finally {
    loginBtn.disabled = false;
  }
});

logoutBtn.addEventListener('click', async () => {
  await chrome.storage.local.remove(['token','user']);
  chrome.runtime.sendMessage({ action: 'TOKEN_CLEARED' });
  authMsg.textContent = 'Đã đăng xuất';
  await refreshAuthUI();
});

// ====== Open Side Panel ======
UI.openPanelBtn.addEventListener('click', async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (!tab || !tab.id) {
      throw new Error('Không tìm thấy tab đang hoạt động');
    }

    // Inject cả script khởi tạo (tạo DOM) và script React vào trang.
    // Cả hai sẽ chạy trong môi trường content script.
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: [
        'side-panel-init.js', // 1. Inject script để tạo DOM container và load CSS
        'build/side-panel.js', // 2. Sau đó inject React app vào container đã tạo
      ],
    });

    showSuccess('Panel đã mở!');

    // Đóng popup sau 1 giây
    setTimeout(() => window.close(), 1000);
  } catch (err) {
    console.error('[popup] Lỗi mở panel:', err);
    showError('❌ Không thể mở panel: ' + err.message);
  }
});

// ====== Translate Page ======
UI.translatePageBtn.addEventListener('click', async () => {
  try {
    setLoading(UI.translatePageBtn, true);
    updateStatus('Đang dịch trang...', true);
    
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    const response = await chrome.tabs.sendMessage(tab.id, {
      action: 'GET_IMAGE_LIST',
    });

    if (!response?.ok) {
      throw new Error('Không thể lấy danh sách ảnh: ' + (response?.error || 'Unknown error'));
    }

    const imageCount = response.images?.length || 0;
    if (imageCount === 0) {
      throw new Error('Không tìm thấy ảnh trên trang này');
    }

    // Gọi background script để xử lý
    const result = await chrome.runtime.sendMessage({
      action: 'PROCESS_PAGE_IMAGES',
      apiUrl: 'http://localhost:7000',
      source_language: 'ch',
      target_language: 'vi',
    });

    if (result.ok) {
      showSuccess(`Đã dịch ${result.processed}/${result.total} ảnh`);
      updateStatus(`Hoàn thành: ${result.processed}/${result.total} ảnh`, false);
    } else {
      throw new Error(result.error);
    }
  } catch (err) {
    console.error('[popup] Lỗi dịch trang:', err);
    showError(err.message);
    updateStatus('Có lỗi xảy ra', false);
  } finally {
    setLoading(UI.translatePageBtn, false);
  }
});

// ====== Translate All (Batch) ======
UI.translateAllBtn.addEventListener('click', async () => {
  try {
    setLoading(UI.translateAllBtn, true);
    updateStatus('Đang dịch toàn bộ...', true);
    
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    // Gọi background script
    const result = await chrome.runtime.sendMessage({
      action: 'PROCESS_PAGE_IMAGES',
      apiUrl: 'http://localhost:7000',
      source_language: 'ch',
      target_language: 'vi',
      batch: true,
    });

    if (result.ok) {
      showSuccess(`Đã dịch ${result.processed}/${result.total} ảnh`);
      updateStatus(`Hoàn thành: ${result.processed}/${result.total} ảnh`, false);
    } else {
      throw new Error(result.error);
    }
  } catch (err) {
    console.error('[popup] Lỗi dịch toàn bộ:', err);
    showError(err.message);
    updateStatus('Có lỗi xảy ra', false);
  } finally {
    setLoading(UI.translateAllBtn, false);
  }
});

// ====== Function được inject vào trang ======
function injectSidePanel() {
  // Check xem panel đã tồn tại chưa
  if (document.getElementById('codenova-side-panel')) {
    return console.log('[content] Side panel already exists');
  }

  // Tạo container cho side panel
  const container = document.createElement('div');
  container.id = 'codenova-side-panel';
  container.style.cssText = `
    position: fixed;
    right: 0;
    top: 0;
    width: 96;
    height: 100vh;
    z-index: 99999;
    background: white;
    box-shadow: -2px 0 8px rgba(0,0,0,0.1);
  `;

  document.body.appendChild(container);

  // Load React component
  const script = document.createElement('script');
  script.src = chrome.runtime.getURL('side-panel-component.js');
  script.onload = () => {
    // Component đã được load
    console.log('[content] Side panel component loaded');
  };
  document.head.appendChild(script);
}

// ====== Initialize ======
console.log('[popup] Popup initialized');
// Init auth UI
refreshAuthUI();