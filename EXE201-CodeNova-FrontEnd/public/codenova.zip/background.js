const DEFAULT_API_URL = 'http://localhost:7000';
let currentTaskAbortController = null;

console.log('[background] Default API URL:', DEFAULT_API_URL);

// ====== Logging Helper ======
function log(message, data = null) {
  const timestamp = new Date().toISOString().split('T')[1].slice(0, -1);
  console.log(`[${timestamp}] [background] ${message}`);
  if (data) console.log(data);
}

function logError(message, error) {
  const timestamp = new Date().toISOString().split('T')[1].slice(0, -1);
  console.error(`[${timestamp}] [background] ❌ ${message}`);
  console.error(error);
}

// === Auth helpers ===
async function getStoredToken() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['token'], (res) => {
      resolve(res?.token || null);
    });
  });
}

async function getAuthHeaders() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['token'], (res) => {
      const headers = {};
      if (res && res.token) {
        headers['Authorization'] = 'Bearer ' + res.token;
      }
      resolve(headers);
    });
  });
}

// 🚀 Lớp lỗi tùy chỉnh để xử lý lỗi token không hợp lệ
class InvalidTokenError extends Error {
  constructor(message) {
    super(message);
    this.name = 'InvalidTokenError';
  }
}

// ====== Helper: Parse API Error ======
function parseApiError(status, errorText) {
  let detail = `API returned status ${status}.`;
  try {
    const errorJson = JSON.parse(errorText);
    const errorDetail = errorJson.detail;
    if (errorDetail && typeof errorDetail === 'string' && errorDetail.trim() !== '') {
      detail = errorDetail;
      // 🚀 Nếu lỗi liên quan đến token, throw lỗi tùy chỉnh
      if (status === 401 || status === 403 || detail.toLowerCase().includes('token')) {
        return new InvalidTokenError(detail);
      }
    } else if (status === 500) {
      detail = 'Lỗi không xác định từ server (Internal Server Error). Vui lòng kiểm tra log của backend.';
    }
  } catch (e) { /* Not a JSON response */ }
  return new Error(detail);
}

// ====== Shared Helpers ======
function sanitizeFilename(name) {
  const safeName = String(name || 'downloaded_image')
    .replace(/[/\\?%*:|"<>]/g, '_')
    .slice(0, 200);
  if (!/\.(jpg|jpeg|png|webp|gif)$/i.test(safeName)) {
    return `${safeName}.jpg`;
  }
  return safeName;
}

// ====== API Health Check ======
async function checkApiHealth(apiUrl, retries = 2, signal) {
  for (let attempt = 1; attempt <= retries; attempt++) {
    if (signal?.aborted) throw new DOMException('Aborted', 'AbortError');
    try {
      log(`Checking API health (attempt ${attempt}/${retries}): ${apiUrl}/health`);
      
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort('Timeout'), 10000); // 🚀 Reduced from 20s to 10s
      
      if (signal) {
        signal.addEventListener('abort', () => controller.abort(), { once: true });
      }
      
      const headers = await getAuthHeaders();
      const response = await fetch(`${apiUrl}/health`, {
        method: 'GET',
        signal: controller.signal,
        headers: Object.keys(headers).length ? headers : undefined
      });
      
      clearTimeout(timeoutId);
      
      if (!response.ok) {
        throw new Error(`Health check failed with status ${response.status}`);
      }
      
      const data = await response.json();
      log('✅ API is healthy', data);
      return { ok: true, data };
      
    } catch (error) {
      if (signal?.aborted) {
        throw new DOMException('Aborted', 'AbortError');
      }

      if (error.name === 'AbortError') {
        logError(`API health check timed out (attempt ${attempt}/${retries})`, error);
      } else {
        logError(`API health check failed (attempt ${attempt}/${retries})`, error);
      }
      
      if (attempt < retries) {
        const delay = 500 * attempt; // 🚀 Reduced retry delay
        log(`Retrying in ${delay}ms...`);
        await new Promise(resolve => setTimeout(resolve, delay));
      } else {
        return { ok: false, error: 'Không thể kết nối đến server backend. Vui lòng đảm bảo server đang chạy và có thể truy cập.' };
      }
    }
  }
  return { ok: false, error: 'Max retries exceeded' };
}

// ====== Process Single Image ======
async function processSingleImage(imageBlob, filename, apiUrl, source_language, target_language, signal) {
  const formData = new FormData();
  formData.append('files', imageBlob, filename);
  formData.append('source_language', source_language);
  formData.append('target_language', target_language);

  log(`Processing single image: ${filename}`);

  const extraHeaders = await getAuthHeaders();
  // If body is FormData, do not set Content-Type
  const fetchOptions = {
    method: 'POST',
    body: formData,
    signal: signal
  };
  // merge headers in if any
  if (Object.keys(extraHeaders).length) {
    fetchOptions.headers = extraHeaders;
  }

  const response = await fetch(`${apiUrl}/process_direct`, fetchOptions);

  if (!response.ok) {
    const errorText = await response.text();
    throw parseApiError(response.status, errorText);
  }

  const result = await response.json();

  if (result && Array.isArray(result.results) && result.results.length > 0) {
    log(`✅ Image processed successfully: ${filename}`);
    return result.results[0];
  } else {
    logError(`API returned unexpected format for single image`, result);
    throw new Error('API returned unexpected format for single image.');
  }
}

// ====== 🚀 OPTIMIZED: Larger chunks + parallel processing ======
function chunkArray(arr, size) {
  const out = [];
  for (let i = 0; i < arr.length; i += size) {
    out.push(arr.slice(i, i + size));
  }
  return out;
}

async function processBatchInChunks(imageBlobList, apiUrl, source_language, target_language, chunkSize = 15, onProgress, signal) {
  log(`Processing ${imageBlobList.length} images in chunks of ${chunkSize}`);
  const chunks = chunkArray(imageBlobList, chunkSize);
  const aggregated = { results: [], successful: 0, failed: 0 };

  // 🚀 Process multiple chunks in parallel (2 at a time)
  const PARALLEL_CHUNKS = 2;
  
  for (let ci = 0; ci < chunks.length; ci += PARALLEL_CHUNKS) {
    if (signal?.aborted) {
      log('Chunk processing cancelled.');
      throw new DOMException('Aborted', 'AbortError');
    }

    const parallelChunks = chunks.slice(ci, ci + PARALLEL_CHUNKS);
    const endChunkIndex = Math.min(ci + parallelChunks.length, chunks.length);
    log(`Processing chunks ${ci+1}-${endChunkIndex}/${chunks.length} in parallel`);

    if (typeof onProgress === 'function') {
      onProgress({
        current: aggregated.successful + aggregated.failed,
        total: imageBlobList.length,
        message: `Processing chunks ${ci + 1}-${endChunkIndex}/${chunks.length}...`
      });
    }

    // 🚀 Process chunks in parallel
    const chunkPromises = parallelChunks.map(async (chunk, idx) => {
      const chunkIndex = ci + idx;
      try {
        const res = await processBatchImages(chunk, apiUrl, source_language, target_language, signal);
        const rlist = Array.isArray(res.results) ? res.results : [];
        log(`Chunk ${chunkIndex+1} done: ${rlist.length} results`);
        return { success: true, results: rlist, res };
      } catch (e) {
        if (e.name === 'AbortError') throw e;
        logError(`Chunk ${chunkIndex+1} failed`, e);
        return {
          success: false,
          results: chunk.map(c => ({
            status: 'error',
            originalFilename: c.filename,
            error: `Chunk upload failed: ${e.message || String(e)}`
          }))
        };
      }
    });

    const results = await Promise.all(chunkPromises);

    // Aggregate results
    results.forEach(({ success, results: rlist, res }) => {
      aggregated.results.push(...rlist);
      if (success) {
        aggregated.successful += res.successful || rlist.filter(x => x.status === 'success').length;
        aggregated.failed += res.failed || rlist.filter(x => x.status === 'error').length;
      } else {
        aggregated.failed += rlist.length;
      }
    });
  }

  if (typeof onProgress === 'function') {
    onProgress({
      current: aggregated.successful + aggregated.failed,
      total: imageBlobList.length,
      message: 'Processing complete.'
    });
  }

  return aggregated;
}

// ====== Process Batch Images ======
async function processBatchImages(imageBlobList, apiUrl, source_language, target_language, signal) {
  const formData = new FormData();
  
  for (const { blob, filename } of imageBlobList) {
    formData.append('files', blob, filename);
  }
  formData.append('source_language', source_language);
  formData.append('target_language', target_language);

  log(`Processing batch of ${imageBlobList.length} images`);

  const extraHeaders = await getAuthHeaders();
  const response = await fetch(`${apiUrl}/process_batch`, {
    method: 'POST',
    body: formData,
    signal,
    headers: Object.keys(extraHeaders).length ? extraHeaders : undefined
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw parseApiError(response.status, errorText);
  }

  const result = await response.json();
  log(`✅ Batch processing complete`, result);
  return result;
}

// ====== Helper: Send message to tab, inject content script if needed ======
async function sendMessageToTabWithInjection(tabId, message) {
  try {
    return await chrome.tabs.sendMessage(tabId, message);
  } catch (err) {
    log('Content script not ready, injecting and retrying...', err.message);

    if (!chrome.scripting || !chrome.scripting.executeScript) {
      throw new Error('chrome.scripting API is not available. Check manifest permissions.');
    }

    await chrome.scripting.executeScript({
      target: { tabId },
      files: ['content.js'],
    });

    await new Promise(resolve => setTimeout(resolve, 300)); // 🚀 Reduced from 500ms

    return await chrome.tabs.sendMessage(tabId, message);
  }
}

// ====== 🚀 OPTIMIZED: Process Page Images with Streaming Replacement ======
async function processPageImages(tabId, msg, onProgress, signal) {
  const { 
    apiUrl = DEFAULT_API_URL, 
    source_language = 'ch', 
    target_language = 'vi',
    images: selectedImages // 🚀 Đổi tên để tránh xung đột, nhận danh sách ảnh đã chọn
  } = msg;

  log('='.repeat(60));
  log(`Starting image processing`);
  log(`API: ${apiUrl}`);
  log(`Source: ${source_language} → Target: ${target_language}`);

  const health = await checkApiHealth(apiUrl, 2, signal); // 🚀 Reduced from 3 retries to 2
  if (!health.ok) {
    throw new Error(`API is not available: ${health.error}`);
  }
  if (signal?.aborted) throw new DOMException('Aborted', 'AbortError');

  if (typeof onProgress === 'function') {
    onProgress({ current: 0, total: 1, message: 'API healthy. Getting image list...' });
  }

  let images;
  // 🚀 KIỂM TRA XEM CÓ DANH SÁCH ẢNH ĐƯỢC CHỌN GỬI TỪ PANEL KHÔNG
  if (selectedImages && selectedImages.length > 0) {
    log(`Processing ${selectedImages.length} selected images from panel.`);
    images = selectedImages;
  } else {
    log('No selected images provided. Requesting full image list from content script...');
    const listResponse = await sendMessageToTabWithInjection(tabId, { action: 'GET_IMAGE_LIST' });

    if (!listResponse || !listResponse.ok || !Array.isArray(listResponse.images)) {
      throw new Error(listResponse?.error || 'Cannot get image list from content script.');
    }
    images = listResponse.images;
  }

  if (images.length === 0) {
    return { ok: true, processed: 0, total: 0, message: 'No images to process' };
  }

  if (typeof onProgress === 'function') {
    const total = images?.length || 0;
    onProgress({ 
      current: 0, 
      total: total, 
      message: `Processing ${total} images. Fetching data...` 
    });
  }

  log('Requesting content script to fetch images...');
  const fetchResponse = await chrome.tabs.sendMessage(tabId, {
    action: 'FETCH_IMAGES_AS_BLOBS',
    // 🚀 Gửi danh sách ảnh (đã chọn hoặc toàn bộ) để fetch
    images: images.map(img => ({
      src: img.src,
      filename: img.filename
    }))
  });

  if (!fetchResponse || !fetchResponse.ok) {
    throw new Error(fetchResponse?.error || 'Failed to fetch image data');
  }

  const imageBlobsData = fetchResponse.blobs || [];
  log(`Content script fetched ${imageBlobsData.length}/${images.length} images`);

  // 🚀 OPTIMIZED: Direct Uint8Array conversion (faster than Array.from)
  // Make uploaded filenames unique by prefixing with index to avoid collisions
  const imageBlobs = imageBlobsData
    .map((item, idx) => ({ item, idx }))
    .filter(({ item }) => item && item.ok)
    .map(({ item, idx }) => {
      try {
        let arrayBuffer;
        if (Array.isArray(item.arrayBuffer)) {
          arrayBuffer = new Uint8Array(item.arrayBuffer).buffer;
        } else if (item.arrayBuffer instanceof ArrayBuffer) {
          arrayBuffer = item.arrayBuffer;
        } else {
          throw new Error(`Invalid arrayBuffer type: ${typeof item.arrayBuffer}`);
        }

        if (arrayBuffer.byteLength < 100) {
          throw new Error(`Image too small: ${arrayBuffer.byteLength} bytes`);
        }

        // Determine a stable raw filename (prefer fetched filename, fallback to provided images list)
        const rawName = (item.filename && String(item.filename)) || (images[idx] && images[idx].filename) || `image_${idx + 1}.jpg`;
        const clientFilename = `${idx + 1}_${sanitizeFilename(rawName)}`;

        return {
          blob: new Blob([arrayBuffer], { type: item.type || 'image/jpeg' }),
          originalSrc: item.originalSrc || (images[idx] && images[idx].src) || null,
          filename: clientFilename
        };
      } catch (e) {
        logError(`Failed to convert arrayBuffer for ${item.filename}`, e);
        return null;
      }
    })
    .filter(Boolean);

  if (imageBlobs.length === 0) {
    throw new Error('Could not load any image data. The website may be blocking the extension.');
  }

  log(`Sending ${imageBlobs.length} images to API...`);
  
  // 🚀 Use larger chunk size and parallel processing
  const backendResult = await processBatchInChunks(
    imageBlobs, 
    apiUrl, 
    source_language, 
    target_language, 
    15, // 🚀 Increased from 8 to 15
    onProgress, 
    signal
  );

  const processedImages = Array.isArray(backendResult.results) ? backendResult.results : [];
  log(`Received ${processedImages.length} processed images from API`);

  // 🚀 CHỈNH SỬA: Logic để xử lý kết quả từ backend (/process_batch trả về 'url')
  const imagesToReplace = processedImages
    .filter(img => img && img.status === 'success' && (img.url || img.dataUrl))
    .map(processedImg => {
      const newSrc = processedImg.dataUrl || processedImg.url;

      // First try to match by originalSrc if backend provided it
      let original = null;
      if (processedImg.originalSrc) {
        original = imageBlobs.find(b => b.originalSrc && b.originalSrc === processedImg.originalSrc);
      }

      // If not matched by originalSrc, try matching by returned originalFilename
      if (!original && processedImg.originalFilename) {
        // The backend should receive our client-prefixed filenames like '3_image.jpg'
        original = imageBlobs.find(b => b.filename === processedImg.originalFilename);
        if (!original) {
          const nameWithoutExt = processedImg.originalFilename.replace(/\.[^.]+$/, '');
          original = imageBlobs.find(b => b.filename.startsWith(nameWithoutExt));
        }
      }

      // Final fallback: try matching by originalSrc derived from the images list
      if (!original) {
        original = imageBlobs.find(b => b.originalSrc && images.some(img => img.src === b.originalSrc && (processedImg.url && processedImg.url.includes(img.filename || '') )));
      }

      if (!original) {
        log(`❌ Could not find original for processed item: ${processedImg.originalFilename || processedImg.originalSrc}`);
        return null;
      }

      return {
        originalSrc: original.originalSrc,
        newSrc
      };
    })
    .filter(Boolean);

  log(`📊 Images ready for replacement: ${imagesToReplace.length}/${processedImages.length}`);

  if (imagesToReplace.length > 0) {
    // 🚀 CẢI TIẾN: Gửi lô thay thế ảnh một cách ổn định
    const REPLACE_BATCH_SIZE = 5; // Gửi lô nhỏ hơn
    let totalReplaced = 0;
    
    log('='.repeat(60));
    log(`🔄 Starting replacement of ${imagesToReplace.length} images in batches of ${REPLACE_BATCH_SIZE}...`);

    for (let i = 0; i < imagesToReplace.length; i += REPLACE_BATCH_SIZE) {
      if (signal?.aborted) {
        log('⚠️ Replacement cancelled by user.');
        break;
      }

      const batch = imagesToReplace.slice(i, i + REPLACE_BATCH_SIZE);
      const batchNum = Math.floor(i / REPLACE_BATCH_SIZE) + 1;
      
      let retries = 3;
      while (retries > 0) {
        try {
          const replaceResponse = await chrome.tabs.sendMessage(tabId, {
            action: 'REPLACE_IMAGES',
            images: batch
          });
          totalReplaced += replaceResponse?.replaced || 0;
          log(`   ✅ Batch ${batchNum} replaced: ${replaceResponse?.replaced || 0} images (total: ${totalReplaced})`);
          break; // Success
        } catch (replaceErr) {
          retries--;
          if (retries > 0) {
            log(`   ⚠️ Batch ${batchNum} failed (${replaceErr.message}), retrying... (${retries} attempts left)`);
            await new Promise(r => setTimeout(r, 500));
          } else {
            logError(`❌ Failed to replace batch ${batchNum} after all retries`, replaceErr);
          }
        }
      }
      // Thêm độ trễ giữa các lô để content script có thời gian xử lý
      await new Promise(resolve => setTimeout(resolve, 150));
    }
    
    log(`✅ Replacement complete: ${totalReplaced}/${imagesToReplace.length} images replaced`);
  }

  return {
    ok: true,
    processed: imagesToReplace.length,
    total: images.length,
    successful: backendResult.successful || imagesToReplace.length,
    failed: backendResult.failed || (images.length - imagesToReplace.length),
    message: `Successfully processed ${imagesToReplace.length}/${images.length} images`
  };
}

// ====== Message Listener ======
const actionHandlers = {
  PING: async (msg, sender) => {
    return { ok: true, message: 'PONG' };
  },

  GET_USER_PROFILE: async (msg, sender) => {
    const apiUrl = 'http://localhost:5000/api/user/profile'; // Hardcode hoặc lấy từ config
    const token = msg.token;

    if (!token) return { ok: false, error: 'No token provided' };

    try {
      const response = await fetch(apiUrl, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        }
      });

      if (!response.ok) {
        // Nếu token hết hạn (401), trả về lỗi để frontend xử lý
        return { ok: false, error: `Server error: ${response.status}`, status: response.status };
      }

      const data = await response.json();
      return { ok: true, data: data };
    } catch (err) {
      logError('GET_USER_PROFILE failed', err);
      return { ok: false, error: err.message };
    }
  },
  
  CANCEL_PROCESSING: async (msg, sender) => {
    if (currentTaskAbortController) {
      log('Received request to cancel processing.');
      currentTaskAbortController.abort();
      return { ok: true, message: 'Cancellation requested.' };
    }
    log('No active processing task to cancel.');
    return { ok: false, message: 'No active process to cancel.' };
  },

  SAVE_TOKEN_FROM_PAGE: async (msg, sender) => {
    if (!msg?.token) return { ok: false, error: 'No token' };
    await new Promise((res) => chrome.storage.local.set({ token: msg.token, user: msg.user || null }, res));
    log('Token saved from page');
    // Không cần sync ngược lại tab đã gửi, nhưng có thể sync cho các tab khác (nếu dùng getActiveTab)
    return { ok: true };
  },
  
  // 🚀 HANDLER MỚI: Khi web app đăng xuất
  CLEAR_TOKEN_FROM_PAGE: async (msg, sender) => {
    await new Promise((res) => chrome.storage.local.remove(['token','user'], res));
    log('Token cleared from page request');
    // Không cần sync ngược lại tab đã gửi
    return { ok: true };
  },

  TOKEN_UPDATED: async (msg, sender) => {
   // message from popup after login
    if (msg?.token) {
      await new Promise((res) => chrome.storage.local.set({ token: msg.token, user: msg.user || null }, res));
      log('Token updated via popup');
      // 🚀 Đồng bộ token này VÀO web app
      await syncTokenToActiveTab(msg.token, msg.user);
      return { ok: true };
    }
    return { ok: false, error: 'No token' };
  },

  TOKEN_CLEARED: async (msg, sender) => {
    await new Promise((res) => chrome.storage.local.remove(['token','user'], res));
    log('Token cleared');
    // 🚀 Đồng bộ (xóa) token KHỎI web app
    await clearTokenFromActiveTab();
    return { ok: true };
  },

  API_HEALTH_CHECK: async (msg, sender) => {
    const apiUrl = msg.apiUrl || DEFAULT_API_URL;
    return await checkApiHealth(apiUrl);
  },

  DOWNLOAD_PAGE_IMAGES: async (msg, sender) => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.id) throw new Error('Không tìm thấy tab hoạt động.');

    log('Requesting image list from content script...');
    const listResponse = await chrome.tabs.sendMessage(tab.id, { action: 'GET_IMAGE_LIST' });

    if (!listResponse?.ok || !listResponse.images) {
      throw new Error(listResponse?.error || 'Không thể lấy danh sách ảnh.');
    }

    const images = listResponse.images;
    const total = images.length;
    if (total === 0) return { ok: true, downloaded: 0, total: 0 };

    let downloadedCount = 0;
    const downloadPromises = images.map((image) =>
      chrome.downloads
        .download({ url: image.src, filename: sanitizeFilename(image.filename), saveAs: false })
        .then((downloadId) => {
          if (downloadId) downloadedCount++;
        })
        .catch((err) => {
          logError(`Download API error for ${image.src}`, err);
        })
    );

    await Promise.allSettled(downloadPromises);
    return { ok: true, downloaded: downloadedCount, total };
  },

  PROCESS_PAGE_IMAGES: async (msg, sender, sendResponse) => {
    sendResponse({ ok: true, status: 'started', message: 'Processing initiated.' });

    if (currentTaskAbortController) {
      throw new Error('Một tác vụ xử lý khác đang chạy. Vui lòng đợi hoặc dừng tác vụ hiện tại.');
    }

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.id) throw new Error('Không tìm thấy tab hoạt động.');

    currentTaskAbortController = new AbortController();
    const signal = currentTaskAbortController.signal;

    const forwardProgress = (progress) => {
      try {
        const targetId = sender?.tab?.id || tab.id;
        chrome.tabs.sendMessage(targetId, { action: 'PROCESSING_PROGRESS', ...progress });
      } catch (e) {
        if (!e.message.includes('Receiving end does not exist')) {
          logError('Failed to send progress update', e);
        }
      }
    };

    try {
      const result = await processPageImages(tab.id, msg, forwardProgress, signal);      
      chrome.tabs.sendMessage(sender.tab.id, {
        action: 'PROCESSING_COMPLETE',
        ...result
      }).catch(e => logError('Failed to send final result to tab', e));
    } catch (err) {
      // 🚀 Gộp logic xử lý lỗi vào một khối catch duy nhất
      if (err instanceof InvalidTokenError) {
        log('Invalid token detected. Clearing token and notifying user.');
        await clearTokenFromActiveTab(); // Xóa token ở cả extension và web app
        err.message = 'Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại.';
      }

      if (err.name === 'AbortError') {
        log('Task was cancelled.');
        chrome.tabs.sendMessage(sender.tab.id, {
          action: 'PROCESSING_COMPLETE',
          ok: false, error: 'Processing was cancelled by the user.', wasCancelled: true
        }).catch(e => logError('Failed to send cancellation message to tab', e));
      } else {
        logError('Error in PROCESS_PAGE_IMAGES handler', err);
        chrome.tabs.sendMessage(sender.tab.id, {
          action: 'PROCESSING_COMPLETE',
          ok: false, error: err?.message || String(err)
        }).catch(e => logError('Failed to send error message to tab', e));
      }
    } finally {
      currentTaskAbortController = null;
      log('Processing task finished or was cancelled. Controller cleaned up.');
    }
  },

  PROCESS_SINGLE_IMAGE: async (msg, sender, sendResponse) => {
    sendResponse({ ok: true, status: 'started', message: 'Single image processing initiated.' });
    
    if (currentTaskAbortController) {
      throw new Error('Một tác vụ xử lý khác đang chạy. Vui lòng đợi hoặc dừng tác vụ hiện tại.');
    }

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.id) throw new Error('Không tìm thấy tab hoạt động.');

    const { image, apiUrl = DEFAULT_API_URL, source_language, target_language } = msg;
    if (!image || !image.src) throw new Error('Thông tin ảnh không hợp lệ.');

    currentTaskAbortController = new AbortController();
    const signal = currentTaskAbortController.signal;

    const forwardProgress = (progress) => {
      try {
        const targetId = sender?.tab?.id || tab.id;
        chrome.tabs.sendMessage(targetId, { action: 'PROCESSING_PROGRESS', ...progress });
      } catch (e) {
        if (!e.message.includes('Receiving end does not exist')) {
          logError('Failed to send progress update', e);
        }
      }
    };

    try {
      log('='.repeat(60));
      log(`Starting single image processing for: ${image.src}`);

      forwardProgress({ current: 0, total: 1, message: 'Fetching image data...' });

      const fetchResponse = await sendMessageToTabWithInjection(tab.id, {
        action: 'FETCH_IMAGES_AS_BLOBS',
        images: [{ src: image.src, filename: image.filename }]
      });

      if (!fetchResponse?.ok || !fetchResponse.blobs?.[0]) {
        throw new Error(fetchResponse?.error || 'Không thể tải dữ liệu ảnh.');
      }

      const blobData = fetchResponse.blobs[0];
      
      if (!blobData.ok || !blobData.arrayBuffer) {
        throw new Error(blobData.error || 'Content script failed to fetch image');
      }

      let arrayBuffer;
      if (Array.isArray(blobData.arrayBuffer)) {
        arrayBuffer = new Uint8Array(blobData.arrayBuffer).buffer;
      } else if (blobData.arrayBuffer instanceof ArrayBuffer) {
        arrayBuffer = blobData.arrayBuffer;
      } else {
        throw new Error(`Invalid arrayBuffer type: ${typeof blobData.arrayBuffer}`);
      }

      if (arrayBuffer.byteLength < 100) {
        throw new Error(`Image data too small: ${arrayBuffer.byteLength} bytes`);
      }

      const imageBlob = new Blob([arrayBuffer], { 
        type: blobData.type || 'image/jpeg' 
      });

      forwardProgress({ current: 0, total: 1, message: 'Sending to backend...' });

      const backendResult = await processSingleImage(
        imageBlob, 
        sanitizeFilename(image.filename || image.src),
        apiUrl, 
        source_language, 
        target_language, 
        signal
      );

      if (backendResult.status !== 'success' || !backendResult.dataUrl) {
        throw new Error(backendResult.error || 'Backend xử lý ảnh thất bại.');
      }

      const imageToReplace = { originalSrc: image.src, newSrc: backendResult.dataUrl };
      try {
        const replaceResponse = await chrome.tabs.sendMessage(tab.id, {
          action: 'REPLACE_IMAGES',
          images: [imageToReplace]
        });
        log(`✅ Single image processed and replaced: ${replaceResponse?.replaced || 0} instances.`);
      } catch (replaceErr) {
        logError('Failed to replace single image on page', replaceErr);
      }

      forwardProgress({ current: 1, total: 1, message: 'Done' });
      log('='.repeat(60));

      chrome.tabs.sendMessage(sender.tab.id, {
        action: 'PROCESSING_COMPLETE',
        ok: true, 
        processed: 1, 
        total: 1, 
        singleImageResult: backendResult
      }).catch(e => logError('Failed to send final result to tab', e));

    } catch (err) {
      // 🚀 Gộp logic xử lý lỗi vào một khối catch duy nhất
      if (err instanceof InvalidTokenError) {
        log('Invalid token detected during single image processing. Clearing token.');
        await clearTokenFromActiveTab();
        err.message = 'Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại.';
      } else if (err.name === 'AbortError') {
        log('Single image task was cancelled.');
        chrome.tabs.sendMessage(sender.tab.id, {
          action: 'PROCESSING_COMPLETE',
          ok: false,
          error: 'Processing was cancelled by the user.',
          wasCancelled: true
        }).catch(e => logError('Failed to send cancellation message to tab', e));
      } else {
        logError('Error in PROCESS_SINGLE_IMAGE handler', err);
        chrome.tabs.sendMessage(sender.tab.id, {
          action: 'PROCESSING_COMPLETE',
          ok: false,
          error: err?.message || String(err)
        }).catch(e => logError('Failed to send error message to tab', e));
      }
    } finally {
      currentTaskAbortController = null;
      log('Single image task finished or was cancelled. Controller cleaned up.');
    }
  },

  FETCH_IMAGE_LIST_FROM_PANEL: async (msg, sender) => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.id) throw new Error('Không tìm thấy tab hoạt động.');

    const listResponse = await sendMessageToTabWithInjection(tab.id, {
      action: 'GET_IMAGE_LIST',
      minSize: msg.minSize || 200
    });

    if (!listResponse?.ok) throw new Error(listResponse?.error || 'Không thể lấy danh sách ảnh từ content script.');
    return listResponse;
  },

  FETCH_IMAGE_PROXY: async (msg, sender) => {
    const url = msg.url;
    log(`[FETCH_IMAGE_PROXY] Start fetching: ${url}`);

    try {
      const tabUrl = sender?.tab?.url || msg.referer;
      const referer = tabUrl || new URL(url).origin + '/';
      const urlObj = new URL(url);

      log(`[FETCH_IMAGE_PROXY] Getting cookies for ${urlObj.hostname}...`);
      const cookies = await chrome.cookies.getAll({ 
        domain: urlObj.hostname 
      }).catch(() => []);
      
      const parentDomain = urlObj.hostname.split('.').slice(-2).join('.');
      const parentCookies = await chrome.cookies.getAll({ 
        domain: '.' + parentDomain 
      }).catch(() => []);
      
      const allCookies = [...cookies, ...parentCookies];
      log(`[FETCH_IMAGE_PROXY] Found ${allCookies.length} cookies`);
      
      const cookieHeader = allCookies
        .map(c => `${c.name}=${c.value}`)
        .join('; ');
      
      const headers = {
        'Accept': 'image/avif,image/webp,image/apng,image/png,image/svg+xml,image/*,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Referer': referer,
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Sec-Fetch-Dest': 'image',
        'Sec-Fetch-Mode': 'no-cors',
        'Sec-Fetch-Site': 'same-origin',
      };
      
      if (cookieHeader) {
        headers['Cookie'] = cookieHeader;
        log(`[FETCH_IMAGE_PROXY] Using ${allCookies.length} cookies`);
      }

      log(`[FETCH_IMAGE_PROXY] Fetching with headers...`);
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 20000); // 🚀 Reduced from 30s to 20s
      
      const response = await fetch(url, {
        method: 'GET',
        headers,
        credentials: 'omit',
        cache: 'no-store',
        signal: controller.signal
      });
      
      clearTimeout(timeoutId);
      
      log(`[FETCH_IMAGE_PROXY] Response: ${response.status} ${response.statusText}`);
      log(`[FETCH_IMAGE_PROXY] Content-Type: ${response.headers.get('content-type')}`);
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const blob = await response.blob();
      log(`[FETCH_IMAGE_PROXY] Received ${blob.size} bytes, type: ${blob.type}`);
      
      if (blob.size < 100) {
        throw new Error(`Response too small: ${blob.size} bytes`);
      }
      
      const arrayBuffer = await blob.arrayBuffer();
      
      // Validate image signature
      const bytes = new Uint8Array(arrayBuffer.slice(0, 50));
      const hex = Array.from(bytes.slice(0, 16))
        .map(b => b.toString(16).padStart(2, '0'))
        .join(' ');
      log(`[FETCH_IMAGE_PROXY] First 16 bytes: ${hex}`);
      
      let isValidImage = false;
      let detectedFormat = 'unknown';
      
      if (bytes[0] === 0xFF && bytes[1] === 0xD8) {
        isValidImage = true;
        detectedFormat = 'JPEG';
        log(`[FETCH_IMAGE_PROXY] ✅ Valid JPEG signature`);
      } else if (bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4E && bytes[3] === 0x47) {
        isValidImage = true;
        detectedFormat = 'PNG';
        log(`[FETCH_IMAGE_PROXY] ✅ Valid PNG signature`);
      } else if (bytes[0] === 0x47 && bytes[1] === 0x49 && bytes[2] === 0x46) {
        isValidImage = true;
        detectedFormat = 'GIF';
        log(`[FETCH_IMAGE_PROXY] ✅ Valid GIF signature`);
      } else if (bytes[0] === 0x52 && bytes[1] === 0x49 && bytes[2] === 0x46 && bytes[3] === 0x46) {
        isValidImage = true;
        detectedFormat = 'WEBP';
        log(`[FETCH_IMAGE_PROXY] ✅ Valid WEBP signature`);
      } else if (bytes[0] === 0x3C) {
        const text = new TextDecoder().decode(bytes);
        log(`[FETCH_IMAGE_PROXY] ❌ Received HTML: ${text.substring(0, 100)}`);
        throw new Error('Server returned HTML instead of image (access denied or 404)');
      } else {
        log(`[FETCH_IMAGE_PROXY] ⚠️ Unknown format. First bytes: ${hex}`);
        try {
          const text = new TextDecoder().decode(bytes);
          if (/^[\x20-\x7E\s]+$/.test(text.substring(0, 50))) {
            log(`[FETCH_IMAGE_PROXY] Content appears to be text: ${text.substring(0, 100)}`);
            throw new Error(`Server returned text instead of image: ${text.substring(0, 100)}`);
          }
        } catch (e) {
          // Not text, continue
        }
      }
      
      if (!isValidImage) {
        throw new Error(`Invalid image format. Signature: ${hex}`);
      }
      
      log(`[FETCH_IMAGE_PROXY] ✅ Success: ${detectedFormat}, ${blob.size} bytes`);
      
      return { 
        ok: true, 
        arrayBuffer, 
        contentType: blob.type || `image/${detectedFormat.toLowerCase()}`,
        size: blob.size,
        format: detectedFormat
      };
      
    } catch (e) {
      logError(`[FETCH_IMAGE_PROXY] ❌ Failed to fetch ${url}`, e);
      
      let errorMsg = e.message || String(e);
      if (e.name === 'AbortError') {
        errorMsg = 'Request timeout (20s)';
      }
      
      return { 
        ok: false, 
        error: errorMsg,
        url: url 
      };
    }
  },
};

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const action = msg?.action;
  log(`Received message: ${action}`);
  const handler = actionHandlers[action];
  if (!handler) {
    sendResponse({ ok: false, error: 'Unknown action' });
    return;
  }

  if (action === 'PROCESS_PAGE_IMAGES' || action === 'PROCESS_SINGLE_IMAGE') {
    handler(msg, sender, sendResponse);
  } else {
    (async () => { const res = await handler(msg, sender); sendResponse(res); })();
  }

  return true;
});

// ====== 🚀 HÀM HELPER ĐỒNG BỘ VÀO WEB APP ======

// Lấy tab đang hoạt động
async function getActiveTab() {
  try {
    // Cần quyền activeTab (đã có trong manifest)
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return tab;
  } catch (e) {
    logError("Could not get active tab", e);
    return null;
  }
}

// Helper để tiêm token vào localStorage của tab đang hoạt động
async function syncTokenToActiveTab(token, user) {
  const tab = await getActiveTab();
  if (!tab || !tab.id || !tab.url || !tab.url.startsWith("http")) {
    log("No active http tab found to sync token.");
    return;
  }
  
  log(`Attempting to sync token to active tab ${tab.id} (${tab.url})`);
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      // Hàm này sẽ chạy trong context của trang web
      func: (t, u) => {
        try {
          localStorage.setItem('token', t);
          if (u) localStorage.setItem('user', JSON.stringify(u));
          // Gửi message để AuthProvider (React) bắt được ngay
          // Chuyển thành chuỗi JSON để tránh xung đột với listener của trang web
          window.postMessage(JSON.stringify({ type: 'CODENOVA_TOKEN_SAVED', token: t, user: u }), window.origin);
        } catch (e) {
          console.error("Error inside injected script (syncToken):", e.message);
        }
      },
      args: [token, user], // Truyền token và user vào hàm
      injectImmediately: true
    });
    log(`Synced token to active tab ${tab.id}`);
  } catch (e) {
    // Bỏ qua lỗi nếu không tiêm script được (vd: trang chrome://)
    if (!e.message.includes("Cannot access") && !e.message.includes("Cannot script")) {
      logError(`Failed to inject script into tab ${tab.id}`, e);
    }
  }
}

// Helper để xóa token khỏi localStorage của tab đang hoạt động
async function clearTokenFromActiveTab() {
  const tab = await getActiveTab();
  if (!tab || !tab.id || !tab.url || !tab.url.startsWith("http")) {
     log("No active http tab found to clear token.");
    return;
  }
  
  log(`Attempting to clear token from active tab ${tab.id} (${tab.url})`);
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      // Hàm này chạy trong context của trang web
      func: () => {
        try {
          localStorage.removeItem('token');
          localStorage.removeItem('user');
          // Gửi message để AuthProvider (React) bắt được ngay
          // Chuyển thành chuỗi JSON để tránh xung đột
          window.postMessage(JSON.stringify({ type: 'CODENOVA_TOKEN_CLEARED' }), window.origin);
        } catch (e) {
          console.error("Error inside injected script (clearToken):", e.message);
        }
      },
      injectImmediately: true
    });
    log(`Cleared token from active tab ${tab.id}`);
  } catch (e) {
    if (!e.message.includes("Cannot access") && !e.message.includes("Cannot script")) {
      logError(`Failed to inject script into tab ${tab.id}`, e);
    }
  }
}

log('🚀 Background script initialized');
log(`Default API URL: ${DEFAULT_API_URL}`);